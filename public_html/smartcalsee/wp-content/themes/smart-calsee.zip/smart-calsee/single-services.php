<?php
 get_header(); ?>

<main id="main">
  <?php while ( have_posts() ) : the_post(); ?>
    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
      <header class="entry-header">
        <?php if ( has_post_thumbnail() ) the_post_thumbnail('large'); ?>
        <h1><?php the_title(); ?></h1>
      </header>

      <div class="entry-content">
        <?php the_content(); ?>
      </div>

      <footer class="entry-footer">
        <?php the_terms( get_the_ID(), 'service_category', 'Categories: ' ); ?>
        <?php the_terms( get_the_ID(), 'service_tag', 'Tags: ' ); ?>
      </footer>
    </article>
  <?php endwhile; ?>
</main>

<?php get_footer(); ?>

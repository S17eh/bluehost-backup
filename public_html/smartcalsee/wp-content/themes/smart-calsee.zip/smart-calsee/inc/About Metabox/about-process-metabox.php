<?php
/* Add Meta Box */
add_action( 'add_meta_boxes', 'easy_process_add_metabox' );
function easy_process_add_metabox() {
        $screen = get_current_screen();
    if ( ! $screen || $screen->id !== 'page' ) return;
    if ( ! isset( $_GET['post'] ) ) return;

    $about = get_page_by_path( 'about-us' );
    if ( ! $about ) return;

    $about_id = intval( $about->ID );
    $current_post_id = intval( $_GET['post'] );
    if ( $current_post_id === $about_id ) {
    add_meta_box(
        'easy_process_box',
        'Easy To Process Section',
        'easy_process_render_box',
        'page',     // show only on pages
        'normal',
        'high'
    );
}
}

/* Render Meta Box */
function easy_process_render_box( $post ) {
    wp_nonce_field( 'easy_process_nonce_action', 'easy_process_nonce' );

    $title   = get_post_meta( $post->ID, '_easy_process_title', true );
    $desc    = get_post_meta( $post->ID, '_easy_process_description', true );
    $steps   = get_post_meta( $post->ID, '_easy_process_steps', true );

    if ( ! is_array( $steps ) || empty( $steps ) ) {
        $steps = array( array( 'icon_id' => '', 'title' => '' ) );
    }
    ?>

    <!-- Section Title -->
    <p>
        <label for="easy_process_title"><strong>Section Title</strong></label><br>
        <input type="text" name="easy_process_title" id="easy_process_title"
               value="<?php echo esc_attr( $title ); ?>" style="width:100%;">
    </p>

    <!-- Section Description -->
    <p>
        <label for="easy_process_description"><strong>Section Description</strong></label><br>
        <?php
        wp_editor( $desc, 'easy_process_description', array(
            'textarea_name' => 'easy_process_description',
            'media_buttons' => false,
            'textarea_rows' => 5,
        ) );
        ?>
    </p>

    <hr>

    <h4>Process Steps (Repeatable)</h4>

    <div id="easy_process_steps_wrap">
        <?php foreach ( $steps as $s ) :
            $icon_id = ! empty( $s['icon_id'] ) ? intval( $s['icon_id'] ) : '';
            $icon_url = $icon_id ? wp_get_attachment_image_url( $icon_id, 'thumbnail' ) : '';
            $step_title = isset( $s['title'] ) ? $s['title'] : '';
        ?>
        <div class="easy_process_step" style="display:flex; align-items:center; gap:10px; margin-bottom:10px;">
            <input type="hidden" name="easy_process_icon_id[]" class="easy_process_icon_id" value="<?php echo esc_attr( $icon_id ); ?>">

            <div style="width:90px; text-align:center;">
                <img class="easy_process_preview" src="<?php echo esc_url( $icon_url ); ?>"
                     style="max-width:70px; display:<?php echo $icon_url ? 'block' : 'none'; ?>; margin-bottom:6px;">
                <button type="button" class="button easy_process_upload"><?php echo $icon_url ? 'Change' : 'Upload'; ?></button>
                <button type="button" class="button easy_process_remove" style="display:<?php echo $icon_url ? 'inline-block' : 'none'; ?>;">Remove</button>
            </div>

            <div style="flex:1;">
                <input type="text" name="easy_process_step_title[]" placeholder="Step Title"
                       value="<?php echo esc_attr( $step_title ); ?>" style="width:100%;">
            </div>

            <button type="button" class="button easy_process_delete">Remove Step</button>
        </div>
        <?php endforeach; ?>
    </div>

    <p><button type="button" class="button" id="easy_process_add">Add Step</button></p>

    <script type="text/javascript">
    jQuery(document).ready(function($){
        var frame;

        // Add new step
        $('#easy_process_add').on('click', function(e){
            e.preventDefault();
            var tpl = '<div class="easy_process_step" style="display:flex; align-items:center; gap:10px; margin-bottom:10px;">' +
                        '<input type="hidden" name="easy_process_icon_id[]" class="easy_process_icon_id" value="">' +
                        '<div style="width:90px; text-align:center;">' +
                            '<img class="easy_process_preview" src="" style="max-width:70px; display:none; margin-bottom:6px;">' +
                            '<button type="button" class="button easy_process_upload">Upload</button>' +
                            '<button type="button" class="button easy_process_remove" style="display:none;">Remove</button>' +
                        '</div>' +
                        '<div style="flex:1;">' +
                            '<input type="text" name="easy_process_step_title[]" placeholder="Step Title" value="" style="width:100%;">' +
                        '</div>' +
                        '<button type="button" class="button easy_process_delete">Remove Step</button>' +
                      '</div>';
            $('#easy_process_steps_wrap').append(tpl);
        });

        // Delete step
        $(document).on('click', '.easy_process_delete', function(e){
            e.preventDefault();
            $(this).closest('.easy_process_step').remove();
        });

        // Upload icon
        $(document).on('click', '.easy_process_upload', function(e){
            e.preventDefault();
            var $btn = $(this);
            var $row = $btn.closest('.easy_process_step');

            frame = wp.media({
                title: 'Select Step Icon',
                button: { text: 'Use this Icon' },
                multiple: false
            });

            frame.on('select', function(){
                var attachment = frame.state().get('selection').first().toJSON();
                $row.find('.easy_process_icon_id').val(attachment.id);
                var src = (attachment.sizes && attachment.sizes.thumbnail) ? attachment.sizes.thumbnail.url : attachment.url;
                $row.find('.easy_process_preview').attr('src', src).show();
                $row.find('.easy_process_remove').show();
                $btn.text('Change');
            });

            frame.open();
        });

        // Remove icon
        $(document).on('click', '.easy_process_remove', function(e){
            e.preventDefault();
            var $row = $(this).closest('.easy_process_step');
            $row.find('.easy_process_icon_id').val('');
            $row.find('.easy_process_preview').hide().attr('src', '');
            $(this).hide();
            $row.find('.easy_process_upload').text('Upload');
        });
    });
    </script>
    <?php
}

/* Save Meta Box */
add_action( 'save_post', 'easy_process_save_meta' );
function easy_process_save_meta( $post_id ) {
    if ( ! isset( $_POST['easy_process_nonce'] ) || ! wp_verify_nonce( $_POST['easy_process_nonce'], 'easy_process_nonce_action' ) ) {
        return;
    }
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    // Title
    if ( isset( $_POST['easy_process_title'] ) ) {
        update_post_meta( $post_id, '_easy_process_title', sanitize_text_field( wp_unslash( $_POST['easy_process_title'] ) ) );
    }

    // Description
    if ( isset( $_POST['easy_process_description'] ) ) {
        $desc = wp_kses_post( wp_unslash( $_POST['easy_process_description'] ) );
        update_post_meta( $post_id, '_easy_process_description', $desc );
    }

    // Steps
    $icons  = isset( $_POST['easy_process_icon_id'] ) ? array_map( 'intval', wp_unslash( $_POST['easy_process_icon_id'] ) ) : [];
    $titles = isset( $_POST['easy_process_step_title'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['easy_process_step_title'] ) ) : [];

    $steps = [];
    $count = max( count( $icons ), count( $titles ) );
    for ( $i = 0; $i < $count; $i++ ) {
        $id  = $icons[$i] ?? '';
        $ttl = $titles[$i] ?? '';
        if ( empty( $id ) && empty( $ttl ) ) continue;
        $steps[] = [ 'icon_id' => $id, 'title' => $ttl ];
    }

    if ( ! empty( $steps ) ) update_post_meta( $post_id, '_easy_process_steps', $steps );
    else delete_post_meta( $post_id, '_easy_process_steps' );
}
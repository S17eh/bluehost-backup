<?php
/**
 * Meta Box: About Section
 */

/* ---- Register meta box for About page ---- */
add_action( 'add_meta_boxes', 'smart_about_add_metabox' );
function smart_about_add_metabox() {
    $screen = get_current_screen();
    if ( ! $screen ) return;

    if ( $screen->id === 'page' && isset( $_GET['post'] ) ) {
        $about_post = get_page_by_path( 'about-us' ); 
        $about_id = $about_post ? intval( $about_post->ID ) : 0;

        $current_post_id = intval( $_GET['post'] );

        if ( $about_id && $current_post_id === $about_id ) {
            add_meta_box(
                'smart_about_box',
                'About Section',
                'smart_about_render_box',
                'page',
                'normal',
                'high'
            );
        }
    }
}

/*  Render About meta box  */
function smart_about_render_box( $post ) {
    wp_nonce_field( 'smart_about_nonce_action', 'smart_about_nonce' );

    $title   = get_post_meta( $post->ID, '_smart_about_title', true );
    $desc    = get_post_meta( $post->ID, '_smart_about_description', true );
    $stats   = get_post_meta( $post->ID, '_smart_about_stats', true );
    $buttons = get_post_meta( $post->ID, '_smart_about_buttons', true );

    if ( ! is_array( $stats ) )   $stats   = [];
    if ( ! is_array( $buttons ) ) $buttons = [];

    ?>
    <p>
        <label for="smart_about_title"><strong>About Title</strong></label><br>
        <input type="text" name="smart_about_title" id="smart_about_title" value="<?php echo esc_attr( $title ); ?>" style="width:100%;">
    </p>

    <p>
        <label for="smart_about_description"><strong>About Description</strong></label><br>
        <?php
        wp_editor( $desc, 'smart_about_description', [
            'textarea_name' => 'smart_about_description',
            'media_buttons' => false,
            'textarea_rows' => 6,
            'teeny'         => false,
        ] );
        ?>
    </p>

    <hr>

    <h4>Stats</h4>
    <div id="smart_about_stats_wrap">
        <?php
        if ( empty( $stats ) ) $stats = [ [ 'num' => '', 'label' => '' ] ];
        foreach ( $stats as $s ) :
            $num = isset( $s['num'] ) ? $s['num'] : '';
            $lbl = isset( $s['label'] ) ? $s['label'] : '';
        ?>
        <div class="smart_about_stat_row" style="display:flex; gap:8px; margin-bottom:8px;">
            <input type="text" name="smart_about_stats_num[]" placeholder="Number (e.g. 10+)" value="<?php echo esc_attr( $num ); ?>" style="flex:0 0 30%; min-width:0;">
            <input type="text" name="smart_about_stats_lbl[]" placeholder="Label (e.g. Years of Expertise)" value="<?php echo esc_attr( $lbl ); ?>" style="flex:1 1 60%; min-width:0;">
            <button type="button" class="button smart_about_remove_stat" style="flex:0 0 auto; white-space:nowrap;">Remove</button>
        </div>
        <?php endforeach; ?>
    </div>
    <p><button type="button" class="button" id="smart_about_add_stat">Add Stat</button></p>

    <hr>

    <h4>Buttons</h4>
    <div id="smart_about_buttons_wrap">
        <?php
        if ( empty( $buttons ) ) $buttons = [ [ 'text' => '', 'link' => '' ] ];
        foreach ( $buttons as $b ) :
            $text = isset( $b['text'] ) ? $b['text'] : '';
            $link = isset( $b['link'] ) ? $b['link'] : '';
        ?>
        <div class="smart_about_button_row" style="display:flex; gap:8px; margin-bottom:8px; align-items:center;">
            <input type="text" name="smart_about_buttons_text[]" placeholder="Button Text" value="<?php echo esc_attr( $text ); ?>" style="flex:1 1 40%; min-width:0;">
            <input type="url"  name="smart_about_buttons_link[]" placeholder="Button Link" value="<?php echo esc_attr( $link ); ?>" style="flex:1 1 50%; min-width:0;">
            <button type="button" class="button smart_about_remove_button" style="flex:0 0 auto; white-space:nowrap;">Remove</button>
        </div>
        <?php endforeach; ?>
    </div>
    <p><button type="button" class="button" id="smart_about_add_button">Add Button</button></p>

    <script type="text/javascript">
    (function($){
        // Add Stat
        $('#smart_about_add_stat').on('click', function(e){
            e.preventDefault();
            var tpl = '<div class="smart_about_stat_row" style="display:flex; gap:8px; margin-bottom:8px;">' +
                      '<input type="text" name="smart_about_stats_num[]" placeholder="Number (e.g. 10+)" value="" style="flex:0 0 30%; min-width:0;">' +
                      '<input type="text" name="smart_about_stats_lbl[]" placeholder="Label (e.g. Years of Expertise)" value="" style="flex:1 1 60%; min-width:0;">' +
                      '<button type="button" class="button smart_about_remove_stat" style="flex:0 0 auto; white-space:nowrap;">Remove</button>' +
                      '</div>';
            $('#smart_about_stats_wrap').append(tpl);
        });

        // Remove Stat
        $(document).on('click', '.smart_about_remove_stat', function(e){
            e.preventDefault();
            $(this).closest('.smart_about_stat_row').remove();
            if ($('#smart_about_stats_wrap .smart_about_stat_row').length === 0) {
                $('#smart_about_add_stat').trigger('click');
            }
        });

        // Add Button
        $('#smart_about_add_button').on('click', function(e){
            e.preventDefault();
            var tpl = '<div class="smart_about_button_row" style="display:flex; gap:8px; margin-bottom:8px; align-items:center;">' +
                      '<input type="text" name="smart_about_buttons_text[]" placeholder="Button Text" value="" style="flex:1 1 40%; min-width:0;">' +
                      '<input type="url"  name="smart_about_buttons_link[]" placeholder="Button Link" value="" style="flex:1 1 50%; min-width:0;">' +
                      '<button type="button" class="button smart_about_remove_button" style="flex:0 0 auto; white-space:nowrap;">Remove</button>' +
                      '</div>';
            $('#smart_about_buttons_wrap').append(tpl);
        });

        // Remove Button
        $(document).on('click', '.smart_about_remove_button', function(e){
            e.preventDefault();
            $(this).closest('.smart_about_button_row').remove();
            if ($('#smart_about_buttons_wrap .smart_about_button_row').length === 0) {
                $('#smart_about_add_button').trigger('click');
            }
        });
    })(jQuery);
    </script>

    <?php
}

/* ---- Save About meta box ---- */
add_action( 'save_post', 'smart_about_save_meta' );
function smart_about_save_meta( $post_id ) {
    // Verify nonce
    if ( ! isset( $_POST['smart_about_nonce'] ) ||
         ! wp_verify_nonce( $_POST['smart_about_nonce'], 'smart_about_nonce_action' ) ) {
        return;
    }

    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    if ( isset( $_POST['smart_about_title'] ) ) {
        update_post_meta( $post_id, '_smart_about_title', sanitize_text_field( wp_unslash( $_POST['smart_about_title'] ) ) );
    }

    if ( isset( $_POST['smart_about_description'] ) ) {
        $desc = wp_kses_post( wp_unslash( $_POST['smart_about_description'] ) );
        update_post_meta( $post_id, '_smart_about_description', $desc );
    }

    $nums = isset( $_POST['smart_about_stats_num'] ) ? array_map( 'sanitize_text_field', wp_unslash( (array) $_POST['smart_about_stats_num'] ) ) : [];
    $lbls = isset( $_POST['smart_about_stats_lbl'] ) ? array_map( 'sanitize_text_field', wp_unslash( (array) $_POST['smart_about_stats_lbl'] ) ) : [];

    $stats = [];
    $count = max( count( $nums ), count( $lbls ) );
    for ( $i = 0; $i < $count; $i++ ) {
        $num = $nums[$i] ?? '';
        $lbl = $lbls[$i] ?? '';
        if ( $num === '' && $lbl === '' ) continue;
        $stats[] = [ 'num' => $num, 'label' => $lbl ];
    }
    if ( ! empty( $stats ) ) update_post_meta( $post_id, '_smart_about_stats', $stats );
    else delete_post_meta( $post_id, '_smart_about_stats' );

    $texts = isset( $_POST['smart_about_buttons_text'] ) ? array_map( 'sanitize_text_field', wp_unslash( (array) $_POST['smart_about_buttons_text'] ) ) : [];
    $links = isset( $_POST['smart_about_buttons_link'] ) ? array_map( 'esc_url_raw', wp_unslash( (array) $_POST['smart_about_buttons_link'] ) ) : [];

    $buttons = [];
    $countb = max( count( $texts ), count( $links ) );
    for ( $j = 0; $j < $countb; $j++ ) {
        $t = $texts[$j] ?? '';
        $l = $links[$j] ?? '';
        if ( $t === '' && $l === '' ) continue;
        $buttons[] = [ 'text' => $t, 'link' => $l ];
    }
    if ( ! empty( $buttons ) ) update_post_meta( $post_id, '_smart_about_buttons', $buttons );
    else delete_post_meta( $post_id, '_smart_about_buttons' );
}

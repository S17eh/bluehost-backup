<?php

/* Add meta box for About Us page only */
add_action( 'add_meta_boxes', 'smart_about_contact_add_meta_box' );
function smart_about_contact_add_meta_box() {
    $screen = get_current_screen();
    if ( ! $screen || $screen->id !== 'page' ) return;
    if ( ! isset( $_GET['post'] ) ) return;

    $about = get_page_by_path( 'about-us' );
    if ( ! $about ) return;

    $about_id = intval( $about->ID );
    $current_post_id = intval( $_GET['post'] );

    if ( $current_post_id === $about_id ) {
        add_meta_box(
            'smart_about_contact_settings',   
            'About Contact section',        
            'smart_about_contact_render_box', 
            'page',                           
            'normal',                         
            'high'
        );
    }
}

/* Render meta box */
function smart_about_contact_render_box( $post ) {
    wp_nonce_field( 'smart_about_contact_meta_nonce_action', 'smart_about_contact_meta_nonce' );

    $contact_title       = get_post_meta( $post->ID, '_about_contact_title', true );
    $contact_description = get_post_meta( $post->ID, '_about_contact_description', true );
    $button_text         = get_post_meta( $post->ID, '_about_contact_button_text', true );
    $button_link         = get_post_meta( $post->ID, '_about_contact_button_link', true );
    ?>
    <p>
        <label for="about-contact-title"><strong>Contact Title</strong></label><br>
        <input type="text" name="about_contact_title" id="about-contact-title" value="<?php echo esc_attr( $contact_title ); ?>" style="width:100%;">
    </p>

    <p>
        <label for="about-contact-description"><strong>Contact Description</strong></label><br>
        <?php
        wp_editor( $contact_description, 'about_contact_description', array(
            'textarea_name' => 'about_contact_description',
            'media_buttons' => true,
            'textarea_rows' => 6,
            'teeny'         => false,
        ) );
        ?>
    </p>

    <hr>

    <h4>Button Settings</h4>
    <p>
        <label for="about-contact-button-text"><strong>Button Text</strong></label><br>
        <input type="text" name="about_contact_button_text" id="about-contact-button-text" value="<?php echo esc_attr( $button_text ); ?>" style="width:100%;">
    </p>

    <p>
        <label for="about-contact-button-link"><strong>Button Link</strong></label><br>
        <input type="url" name="about_contact_button_link" id="about-contact-button-link" value="<?php echo esc_attr( $button_link ); ?>" style="width:100%;">
    </p>
    <?php
}

/* Save meta box data */
add_action( 'save_post', 'smart_about_contact_save_meta_box' );
function smart_about_contact_save_meta_box( $post_id ) {
    if ( ! isset( $_POST['smart_about_contact_meta_nonce'] ) ||
         ! wp_verify_nonce( $_POST['smart_about_contact_meta_nonce'], 'smart_about_contact_meta_nonce_action' ) ) {
        return;
    }

    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    if ( isset( $_POST['about_contact_title'] ) ) {
        update_post_meta( $post_id, '_about_contact_title', sanitize_text_field( wp_unslash( $_POST['about_contact_title'] ) ) );
    }

    if ( isset( $_POST['about_contact_description'] ) ) {
        $desc = wp_kses_post( wp_unslash( $_POST['about_contact_description'] ) );
        update_post_meta( $post_id, '_about_contact_description', $desc );
    }

    if ( isset( $_POST['about_contact_button_text'] ) ) {
        update_post_meta( $post_id, '_about_contact_button_text', sanitize_text_field( wp_unslash( $_POST['about_contact_button_text'] ) ) );
    }

    if ( isset( $_POST['about_contact_button_link'] ) ) {
        update_post_meta( $post_id, '_about_contact_button_link', esc_url_raw( wp_unslash( $_POST['about_contact_button_link'] ) ) );
    }
}

<?php
add_action( 'add_meta_boxes', 'about_vision_add_metabox' );
function about_vision_add_metabox() {
    $screen = get_current_screen();
    if ( ! $screen ) return;

    if ( $screen->id === 'page' && isset( $_GET['post'] ) ) {
        $about = get_page_by_path( 'about-us' );
        $about_id = $about ? intval( $about->ID ) : 0;
        $current_post_id = intval( $_GET['post'] );

        if ( $about_id && $current_post_id === $about_id ) {
            add_meta_box(
                'about_vision_box',
                'Vision Section',
                'about_vision_render_box',
                'page',
                'normal',
                'high'
            );
        }
    }
}

/* Render meta box */
function about_vision_render_box( $post ) {
    wp_nonce_field( 'about_vision_nonce_action', 'about_vision_nonce' );

    // Load saved values
    $title       = get_post_meta( $post->ID, '_about_vision_title', true );
    $content     = get_post_meta( $post->ID, '_about_vision_content', true );
    $img_id      = get_post_meta( $post->ID, '_about_vision_image_id', true );
    $person_name = get_post_meta( $post->ID, '_about_vision_person_name', true );
    $person_role = get_post_meta( $post->ID, '_about_vision_person_role', true );

    $img_url = $img_id ? wp_get_attachment_image_url( $img_id, 'medium' ) : '';
    ?>
    <p>
        <label for="about_vision_title"><strong>Vision Title</strong></label><br>
        <input type="text" name="about_vision_title" id="about_vision_title" value="<?php echo esc_attr( $title ); ?>" style="width:100%;">
    </p>

    <p>
        <label for="about_vision_content"><strong>Vision Content</strong></label><br>
        <?php
        wp_editor( $content, 'about_vision_content', [
            'textarea_name' => 'about_vision_content',
            'media_buttons' => false,
            'textarea_rows' => 8,
            'teeny'         => false,
        ] );
        ?>
    </p>

    <hr>

    <h4>Portrait (right side)</h4>
    <input type="hidden" id="about_vision_image_id" name="about_vision_image_id" value="<?php echo esc_attr( $img_id ); ?>">
    <div style="margin-bottom:8px;">
        <img id="about_vision_image_preview" src="<?php echo esc_url( $img_url ); ?>" style="max-width:200px; <?php echo $img_url ? '' : 'display:none;'; ?>; border-radius:6px;">
    </div>
    <p>
        <button type="button" class="button" id="about_vision_image_upload"><?php echo $img_url ? 'Change Image' : 'Upload Image'; ?></button>
        <button type="button" class="button" id="about_vision_image_remove" style="<?php echo $img_url ? '' : 'display:none;'; ?>">Remove</button>
    </p>

    <div style="display:flex; gap:10px; align-items:flex-start; margin-top:12px;">
        <div style="flex:1;">
            <label for="about_vision_person_name"><strong>Person Name</strong></label><br>
            <input type="text" name="about_vision_person_name" id="about_vision_person_name"
                   value="<?php echo esc_attr( $person_name ); ?>" style="width:100%;">
        </div>

        <div style="flex:1;">
            <label for="about_vision_person_role"><strong>Person Designation</strong></label><br>
            <input type="text" name="about_vision_person_role" id="about_vision_person_role"
                   value="<?php echo esc_attr( $person_role ); ?>" style="width:100%;">
        </div>
    </div>

    <!-- Robust uploader JS (runs after document ready) -->
    <script type="text/javascript">
    jQuery(document).ready(function($){
        // ensure wp.media is available (about_vision_enqueue_media must have run)
        if ( typeof wp === 'undefined' || ! wp.media ) {
            return;
        }

        var frame = null;

        $('#about_vision_image_upload').on('click', function(e){
            e.preventDefault();

            // If frame already exists, reopen it.
            if ( frame ) {
                frame.open();
                return;
            }

            frame = wp.media({
                title: 'Select Portrait Image',
                button: { text: 'Use this image' },
                multiple: false
            });

            frame.on('select', function(){
                var attachment = frame.state().get('selection').first().toJSON();
                if ( attachment ) {
                    $('#about_vision_image_id').val( attachment.id );
                    var src = (attachment.sizes && attachment.sizes.medium) ? attachment.sizes.medium.url : attachment.url;
                    $('#about_vision_image_preview').attr('src', src).show();
                    $('#about_vision_image_remove').show();
                    $('#about_vision_image_upload').text('Change Image');
                }
            });

            frame.open();
        });

        $('#about_vision_image_remove').on('click', function(e){
            e.preventDefault();
            $('#about_vision_image_id').val('');
            $('#about_vision_image_preview').hide().attr('src','');
            $(this).hide();
            $('#about_vision_image_upload').text('Upload Image');
        });
    });
    </script>

    <?php
}

/* Save meta box */
add_action( 'save_post', 'about_vision_save_meta' );
function about_vision_save_meta( $post_id ) {
    // Verify nonce
    if ( ! isset( $_POST['about_vision_nonce'] ) || ! wp_verify_nonce( $_POST['about_vision_nonce'], 'about_vision_nonce_action' ) ) {
        return;
    }

    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    // Title
    if ( isset( $_POST['about_vision_title'] ) ) {
        update_post_meta( $post_id, '_about_vision_title', sanitize_text_field( wp_unslash( $_POST['about_vision_title'] ) ) );
    }

    // Content (allow safe HTML)
    if ( isset( $_POST['about_vision_content'] ) ) {
        $content = wp_kses_post( wp_unslash( $_POST['about_vision_content'] ) );
        update_post_meta( $post_id, '_about_vision_content', $content );
    }

    // Image (attachment ID)
    if ( isset( $_POST['about_vision_image_id'] ) ) {
        $img_id = intval( $_POST['about_vision_image_id'] );
        if ( $img_id ) update_post_meta( $post_id, '_about_vision_image_id', $img_id );
        else delete_post_meta( $post_id, '_about_vision_image_id' );
    }

    // Person name / role
    if ( isset( $_POST['about_vision_person_name'] ) ) {
        update_post_meta( $post_id, '_about_vision_person_name', sanitize_text_field( wp_unslash( $_POST['about_vision_person_name'] ) ) );
    }
    if ( isset( $_POST['about_vision_person_role'] ) ) {
        update_post_meta( $post_id, '_about_vision_person_role', sanitize_text_field( wp_unslash( $_POST['about_vision_person_role'] ) ) );
    }
}
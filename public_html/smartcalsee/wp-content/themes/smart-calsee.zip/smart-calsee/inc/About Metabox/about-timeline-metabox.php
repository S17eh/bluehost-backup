<?php

/* Add meta box on About Us page only */
add_action( 'add_meta_boxes', 'about_timeline_add_metabox' );
function about_timeline_add_metabox() {
    $screen = get_current_screen();
    if ( ! $screen || $screen->id !== 'page' ) return;
    if ( ! isset( $_GET['post'] ) ) return;

    $about = get_page_by_path( 'about-us' );
    if ( ! $about ) return;

    $about_id = intval( $about->ID );
    $current  = intval( $_GET['post'] );

    if ( $current !== $about_id ) return;

    add_meta_box(
        'about_timeline_box',
        'About Timeline',
        'about_timeline_render_box',
        'page',
        'normal',
        'high'
    );
}

/* Render meta box */
function about_timeline_render_box( $post ) {
    wp_nonce_field( 'about_timeline_nonce_action', 'about_timeline_nonce' );

    $items = get_post_meta( $post->ID, '_about_timeline_items', true );
    if ( ! is_array( $items ) || empty( $items ) ) {
        $items = array( array( 'year' => '', 'headline' => '', 'description' => '' ) );
    }
    ?>
    <div id="about_timeline_wrap">
        <?php foreach ( $items as $i => $it ) :
            $year = isset( $it['year'] ) ? $it['year'] : '';
            $headline = isset( $it['headline'] ) ? $it['headline'] : '';
            $description = isset( $it['description'] ) ? $it['description'] : '';
        ?>
        <div class="about_timeline_item" style="border:1px solid #eee; padding:12px; margin-bottom:10px;">
            <div style="display:flex; gap:10px; align-items:flex-start;">
                <div style="flex:0 0 100px;">
                    <label><strong>Year</strong></label><br>
                    <input type="text" name="about_timeline_year[]" value="<?php echo esc_attr( $year ); ?>" style="width:100%;">
                </div>

                <div style="flex:1;">
                    <label><strong>Headline</strong></label><br>
                    <input type="text" name="about_timeline_headline[]" value="<?php echo esc_attr( $headline ); ?>" style="width:100%;">

                    <label style="margin-top:8px; display:block;"><strong>Description</strong></label>
                    <textarea name="about_timeline_description[]" rows="4" style="width:100%;"><?php echo esc_textarea( $description ); ?></textarea>
                </div>

                <div style="flex:0 0 85px; text-align:right;">
                    <button type="button" class="button about_timeline_remove">Remove</button>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <p><button type="button" class="button" id="about_timeline_add">Add Timeline Item</button></p>

    <script type="text/javascript">
    (function($){
        // Add new item
        $('#about_timeline_add').on('click', function(e){
            e.preventDefault();
            var tpl = '<div class="about_timeline_item" style="border:1px solid #eee; padding:12px; margin-bottom:10px;">' +
                      '<div style="display:flex; gap:10px; align-items:flex-start;">' +
                        '<div style="flex:0 0 100px;">' +
                          '<label><strong>Year</strong></label><br>' +
                          '<input type="text" name="about_timeline_year[]" value="" style="width:100%;">' +
                        '</div>' +
                        '<div style="flex:1;">' +
                          '<label><strong>Headline</strong></label><br>' +
                          '<input type="text" name="about_timeline_headline[]" value="" style="width:100%;">' +
                          '<label style="margin-top:8px; display:block;"><strong>Description</strong></label>' +
                          '<textarea name="about_timeline_description[]" rows="4" style="width:100%;"></textarea>' +
                        '</div>' +
                        '<div style="flex:0 0 85px; text-align:right;">' +
                          '<button type="button" class="button about_timeline_move_up" title="Move up">↑</button>' +
                          '<button type="button" class="button about_timeline_move_down" title="Move down">↓</button><br><br>' +
                          '<button type="button" class="button about_timeline_remove">Remove</button>' +
                        '</div>' +
                      '</div>' +
                    '</div>';
            $('#about_timeline_wrap').append(tpl);
        });

        // Remove item
        $(document).on('click', '.about_timeline_remove', function(e){
            e.preventDefault();
            $(this).closest('.about_timeline_item').remove();
        });

    })(jQuery);
    </script>

    <?php
}

/* Save timeline meta */
add_action( 'save_post', 'about_timeline_save_meta' );
function about_timeline_save_meta( $post_id ) {
    // nonce check
    if ( ! isset( $_POST['about_timeline_nonce'] ) || ! wp_verify_nonce( $_POST['about_timeline_nonce'], 'about_timeline_nonce_action' ) ) {
        return;
    }
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    $years = isset( $_POST['about_timeline_year'] ) ? array_map( 'sanitize_text_field', wp_unslash( (array) $_POST['about_timeline_year'] ) ) : [];
    $heads = isset( $_POST['about_timeline_headline'] ) ? array_map( 'sanitize_text_field', wp_unslash( (array) $_POST['about_timeline_headline'] ) ) : [];
    $descs = isset( $_POST['about_timeline_description'] ) ? array_map( 'wp_kses_post', wp_unslash( (array) $_POST['about_timeline_description'] ) ) : [];

    $items = array();
    $count = max( count( $years ), count( $heads ), count( $descs ) );
    for ( $i = 0; $i < $count; $i++ ) {
        $y = $years[$i] ?? '';
        $h = $heads[$i] ?? '';
        $d = $descs[$i] ?? '';
        if ( $y === '' && $h === '' && $d === '' ) continue;
        $items[] = array( 'year' => $y, 'headline' => $h, 'description' => $d );
    }

    if ( ! empty( $items ) ) update_post_meta( $post_id, '_about_timeline_items', $items );
    else delete_post_meta( $post_id, '_about_timeline_items' );
}

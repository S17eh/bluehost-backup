<?php

// Include all PHP files from specific subfolders inside 'inc'
function include_rewild_files()
{
    $folders = array(
        'Home metabox',
        'Service metabox',
        'About metabox',
        'Team metabox',
        'Contact metabox',
    );

    foreach ($folders as $folder) {
        $folder_path = get_template_directory() . '/inc/' . $folder . '/';

        if (is_dir($folder_path)) {
            foreach (glob($folder_path . '*.php') as $file) {
                include_once $file;
            }
        }
    }
    add_theme_support('custom-logo');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');

    register_nav_menus(array(
        'primary' => __('Primary Menu', 'smart-calsee'),
        'footer' => __('Footer Menu', 'smart-calsee'),
        'legal' => __('Footer Legal', 'smart-calsee'),
        'social' => __('Footer Social', 'smart-calsee'),
    ));

}
add_action('after_setup_theme', 'include_rewild_files');



//svg support
function allow_svg_uploads($mimes)
{
    $mimes['svg'] = 'image/svg+xml';
    return $mimes;
}
add_filter('upload_mimes', 'allow_svg_uploads');

// body class add
function add_custom_body_class($classes)
{
    $classes[] = 'smart-body-dots'; // 👈 your new class
    return $classes;
}
add_filter('body_class', 'add_custom_body_class');

add_action('admin_enqueue_scripts', function () {
    wp_enqueue_media();
});

// Enqueue styles and scripts (Bootstrap, Google Fonts, theme CSS/JS)
function smart_calsee_enqueue_scripts()
{

    // Bootstrap CSS (CDN)
    wp_enqueue_style('bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css', array(), '5.3.2');
    wp_enqueue_style('smart-custom-css', get_template_directory_uri() . '/assets/css/custom.css', true);
    wp_enqueue_style('smart-home-css', get_template_directory_uri() . '/assets/css/home.css', true);

    // wp_enqueue_style( 'smart-calsee-style', get_template_directory_uri() . '/assets/css/custom.css', array(), wp_get_theme()->get( 'Version' ) );
    wp_enqueue_script('bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js', array(), '5.3.2', true);

    wp_enqueue_script('three-js', 'https://cdn.jsdelivr.net/npm/three@0.148.0/build/three.min.js', array(),'0.148.0', true );

    // GSAP Core
    wp_enqueue_script('gsap-js',  get_template_directory_uri() . '/assets/js/gsap.min.js', array(),null,true);

    wp_enqueue_style( 'bootstrap-icons', 'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css' );

    // ScrollTrigger
    wp_enqueue_script('scrolltrigger-js', get_template_directory_uri() . '/assets/js/ScrollTrigger.min.js',array('gsap-js'), null, true);

    // ScrollSmoother
    wp_enqueue_script('scrollsmoother-js', get_template_directory_uri() . '/assets/js/ScrollSmoother.min.js', array('gsap-js'), null, true);

    // Simplex Noise
    wp_enqueue_script( 'simplex-noise-js', 'https://cdnjs.cloudflare.com/ajax/libs/simplex-noise/2.4.0/simplex-noise.min.js',  array(),  '2.4.0', true );
    // Theme JS (optional)
    wp_enqueue_script('smart-calsee-js', get_template_directory_uri() . '/assets/js/custom-script.js', array('jquery'), wp_get_theme()->get('Version'), true);
    wp_localize_script( 'smart-calsee-js', 'ThemeData', [
  'assetsUrl' => get_template_directory_uri() . '/assets/image/'  // trailing slash
] );
}   
add_action('wp_enqueue_scripts', 'smart_calsee_enqueue_scripts');



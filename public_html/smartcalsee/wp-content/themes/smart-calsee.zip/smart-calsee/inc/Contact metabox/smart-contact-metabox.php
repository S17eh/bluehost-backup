<?php
/*---------------------------------
 * Add Meta Box for Contact Page
 *--------------------------------*/
add_action( 'add_meta_boxes', 'contact_info_add_metabox' );
function contact_info_add_metabox() {
    $screen = get_current_screen();
    if ( ! $screen || $screen->id !== 'page' ) return;

    // Only show on "Contact" page (change slug if different)
    $contact_page = get_page_by_path( 'contact-us' );
    if ( ! $contact_page ) return;
    if ( ! isset( $_GET['post'] ) || intval( $_GET['post'] ) !== intval( $contact_page->ID ) ) return;

    add_meta_box(
        'contact_info_box',
        'Contact Page Information',
        'contact_info_render_metabox',
        'page',
        'normal',
        'high'
    );
}

/*---------------------------------
 * Render Meta Box
 *--------------------------------*/
function contact_info_render_metabox( $post ) {
    wp_nonce_field( 'contact_info_nonce_action', 'contact_info_nonce' );

    $phone    = get_post_meta( $post->ID, '_contact_phone', true );
    $email    = get_post_meta( $post->ID, '_contact_email', true );
    $address  = get_post_meta( $post->ID, '_contact_address', true );
    $hours    = get_post_meta( $post->ID, '_contact_hours', true );
    $contact_description = get_post_meta( $post->ID, '_contact_description', true );
    ?>
    <label for="service-description"><strong>Contact Description</strong></label><br>
     <p>
        <label for="contact-description"><strong>Hero Title</strong></label><br>
        <?php
        // wp_editor settings: textarea_name must be hero_description so $_POST uses that name
        $editor_id = 'contact-description';
        $settings = array(
            'textarea_name' => 'contact_description',
            'media_buttons' => true,
            'textarea_rows' => 6,
            'teeny'         => false,
        );
        wp_editor( $contact_description, $editor_id, $settings );
        ?>
    </p>
    <table class="form-table">
        <tr>
            <th><label for="contact_phone">Phone No:</label></th>
            <td><input type="text" name="contact_phone" id="contact_phone" value="<?php echo esc_attr( $phone ); ?>" class="regular-text" placeholder="+91 - 94085 85688"></td>
        </tr>
        <tr>
            <th><label for="contact_email">Email Address:</label></th>
            <td><input type="email" name="contact_email" id="contact_email" value="<?php echo esc_attr( $email ); ?>" class="regular-text" placeholder="business@smartcalsee.com"></td>
        </tr>
        <tr>
            <th><label for="contact_address">Our Address:</label></th>
            <td>
                <textarea name="contact_address" id="contact_address" rows="3" class="large-text" placeholder="Ahmedabad, Gujarat"><?php echo esc_textarea( $address ); ?></textarea>
            </td>
        </tr>
        <tr>
            <th><label for="contact_hours">Business Hours:</label></th>
            <td><input type="text" name="contact_hours" id="contact_hours" value="<?php echo esc_attr( $hours ); ?>" class="regular-text" placeholder="9AM - 6PM"></td>
        </tr>
    </table>
    <?php
}

/*---------------------------------
 * Save Meta Values
 *--------------------------------*/
add_action( 'save_post', 'contact_info_save_meta' );
function contact_info_save_meta( $post_id ) {
    if ( ! isset( $_POST['contact_info_nonce'] ) ) return;
    if ( ! wp_verify_nonce( $_POST['contact_info_nonce'], 'contact_info_nonce_action' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;
    if ( isset( $_POST['contact_description'] ) ) {
        // wp_kses_post allows same tags as post content
        $desc = wp_kses_post( wp_unslash( $_POST['contact_description'] ) );
        update_post_meta( $post_id, '_contact_description', $desc );
    }
    $fields = [
        '_contact_phone'   => sanitize_text_field( $_POST['contact_phone'] ?? '' ),
        '_contact_email'   => sanitize_email( $_POST['contact_email'] ?? '' ),
        '_contact_address' => sanitize_textarea_field( $_POST['contact_address'] ?? '' ),
        '_contact_hours'   => sanitize_text_field( $_POST['contact_hours'] ?? '' ),
    ];

    foreach ( $fields as $key => $val ) {
        if ( ! empty( $val ) ) update_post_meta( $post_id, $key, $val );
        else delete_post_meta( $post_id, $key );
    }
}

<?php

/* Add meta box */
add_action( 'add_meta_boxes', 'team_meta_add_metabox' );
function team_meta_add_metabox() {
    $screen = get_current_screen();
    if ( ! $screen || $screen->id !== 'page' ) return;

    // Optional: restrict to a page with slug "team"
    $team_post = get_page_by_path( 'expert-team' ); // uncomment & change slug if needed
    if ( ! $team_post ) return;
    if ( ! isset( $_GET['post'] ) || intval( $_GET['post'] ) !== intval( $team_post->ID ) ) return;

    add_meta_box(
        'team_members_box',
        'Team Members',
        'team_meta_render_box',
        'page',
        'normal',
        'high'
    );
}

/* 3) Render meta box */
function team_meta_render_box( $post ) {
    wp_nonce_field( 'team_meta_nonce_action', 'team_meta_nonce' );

    $members = get_post_meta( $post->ID, '_team_members', true );
    if ( ! is_array( $members ) || empty( $members ) ) {
        $members = array( array( 'image_id' => '', 'name' => '', 'designation' => '' ) );
    }
    $team_description = get_post_meta( $post->ID, '_team_description', true );
    ?>
     <p>
        <label for="team-description"><strong>Team Description</strong></label><br>
        <?php
        // wp_editor settings: textarea_name must be hero_description so $_POST uses that name
        $editor_id = 'team-description';
        $settings = array(
            'textarea_name' => 'team_description',
            'media_buttons' => true,
            'textarea_rows' => 6,
            'teeny'         => false,
        );
        wp_editor( $team_description, $editor_id, $settings );
        ?>
    </p>
           <label for="team-description"><strong>Team Details</strong></label><br>
    <div id="team_members_wrap">
        <?php foreach ( $members as $m ) :
            $img_id = ! empty( $m['image_id'] ) ? intval( $m['image_id'] ) : '';
            $img_url = $img_id ? wp_get_attachment_image_url( $img_id, 'thumbnail' ) : '';
            $name = isset( $m['name'] ) ? $m['name'] : '';
            $designation = isset( $m['designation'] ) ? $m['designation'] : '';
        ?>
        <div class="team_member_row" style="display:flex; gap:12px; align-items:center; border:1px solid #eee; padding:10px; margin:10px 0px;">
            <input type="hidden" name="team_image_id[]" class="team_image_id" value="<?php echo esc_attr( $img_id ); ?>">

            <div style="width:110px; text-align:center;">
                <img class="team_image_preview" src="<?php echo esc_url( $img_url ); ?>" style="max-width:90px; display:<?php echo $img_url ? 'block' : 'none'; ?>; margin-bottom:6px; border-radius:6px;">
                <div>
                    <button type="button" class="button team_image_upload"><?php echo $img_url ? 'Change' : 'Upload'; ?></button>
                    <button type="button" class="button team_image_remove" style="display:<?php echo $img_url ? 'inline-block' : 'none'; ?>;">Remove</button>
                </div>
            </div>

            <div style="flex:1; display:flex; gap:8px;">
                <input type="text" name="team_member_name[]" placeholder="Full name" value="<?php echo esc_attr( $name ); ?>" style="flex:0 0 40%; min-width:0;">
                <input type="text" name="team_member_designation[]" placeholder="Designation (e.g. Chartered Accountant)" value="<?php echo esc_attr( $designation ); ?>" style="flex:1; min-width:0;">
            </div>

            <div style="flex:0 0 110px; text-align:right;">
                <button type="button" class="button team_member_remove">Remove</button>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <p><button type="button" class="button" id="team_member_add">Add Member</button></p>

    <script type="text/javascript">
    (function($){
        var frame;

        function team_member_template() {
            return '<div class="team_member_row" style="display:flex; gap:12px; align-items:center; border:1px solid #eee; padding:10px; margin-bottom:10px;">' +
                    '<input type="hidden" name="team_image_id[]" class="team_image_id" value="">' +
                    '<div style="width:110px; text-align:center;">' +
                      '<img class="team_image_preview" src="" style="max-width:90px; display:none; margin-bottom:6px; border-radius:6px;">' +
                      '<div>' +
                        '<button type="button" class="button team_image_upload">Upload</button> ' +
                        '<button type="button" class="button team_image_remove" style="display:none;">Remove</button>' +
                      '</div>' +
                    '</div>' +
                    '<div style="flex:1; display:flex; gap:8px;">' +
                      '<input type="text" name="team_member_name[]" placeholder="Full name" value="" style="flex:0 0 40%; min-width:0;">' +
                      '<input type="text" name="team_member_designation[]" placeholder="Designation (e.g. Chartered Accountant)" value="" style="flex:1; min-width:0;">' +
                    '</div>' +
                    '<div style="flex:0 0 110px; text-align:right;">' +
                      '<button type="button" class="button team_member_remove">Remove</button>' +
                    '</div>' +
                   '</div>';
        }

        // add
        $('#team_member_add').on('click', function(e){
            e.preventDefault();
            $('#team_members_wrap').append(team_member_template());
        });

        // remove row
        $(document).on('click', '.team_member_remove', function(e){
            e.preventDefault();
            $(this).closest('.team_member_row').remove();
        });

        // upload image
        $(document).on('click', '.team_image_upload', function(e){
            e.preventDefault();
            var $btn = $(this);
            var $row = $btn.closest('.team_member_row');

            frame = frame || wp.media({
                title: 'Select Portrait',
                button: { text: 'Use this image' },
                multiple: false
            });

            frame.off('select');
            frame.on('select', function(){
                var attachment = frame.state().get('selection').first().toJSON();
                if ( attachment ) {
                    $row.find('.team_image_id').val( attachment.id );
                    var src = (attachment.sizes && attachment.sizes.thumbnail) ? attachment.sizes.thumbnail.url : attachment.url;
                    $row.find('.team_image_preview').attr('src', src).show();
                    $row.find('.team_image_remove').show();
                    $btn.text('Change');
                }
            });

            frame.open();
        });

        // remove image
        $(document).on('click', '.team_image_remove', function(e){
            e.preventDefault();
            var $row = $(this).closest('.team_member_row');
            $row.find('.team_image_id').val('');
            $row.find('.team_image_preview').hide().attr('src','');
            $(this).hide();
            $row.find('.team_image_upload').text('Upload');
        });

    })(jQuery);
    </script>

    <style>
        .team_member_row input[type="text"] { box-sizing:border-box; }
    </style>

    <?php
}

/* 4) Save meta */
add_action( 'save_post', 'team_meta_save' );
function team_meta_save( $post_id ) {
    if ( ! isset( $_POST['team_meta_nonce'] ) ) {
        // if no nonce present bail (prevents accidental save)
    } else {
        if ( ! wp_verify_nonce( $_POST['team_meta_nonce'], 'team_meta_nonce_action' ) ) return;
    }

    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;
    if ( isset( $_POST['team_description'] ) ) {
        // wp_kses_post allows same tags as post content
        $desc = wp_kses_post( wp_unslash( $_POST['team_description'] ) );
        update_post_meta( $post_id, '_team_description', $desc );
    }

    $images = isset( $_POST['team_image_id'] ) ? array_map( 'intval', wp_unslash( (array) $_POST['team_image_id'] ) ) : array();
    $names  = isset( $_POST['team_member_name'] ) ? array_map( 'sanitize_text_field', wp_unslash( (array) $_POST['team_member_name'] ) ) : array();
    $design = isset( $_POST['team_member_designation'] ) ? array_map( 'sanitize_text_field', wp_unslash( (array) $_POST['team_member_designation'] ) ) : array();

    $members = array();
    $count = max( count( $images ), count( $names ), count( $design ) );
    for ( $i = 0; $i < $count; $i++ ) {
        $img = $images[$i] ?? '';
        $nm  = $names[$i] ?? '';
        $ds  = $design[$i] ?? '';
        if ( $img === '' && $nm === '' && $ds === '' ) continue;
        $members[] = array( 'image_id' => $img ? intval( $img ) : '', 'name' => $nm, 'designation' => $ds );
    }

    if ( ! empty( $members ) ) update_post_meta( $post_id, '_team_members', $members );
    else delete_post_meta( $post_id, '_team_members' );
}

<?php
/**
 * Homepage meta box (procedural, classic editor for description)
 */

/* ---------------------------
 * Add meta box (only for homepage)
 * --------------------------- */
add_action( 'add_meta_boxes', 'smart_homepage_add_meta_box' );
function smart_homepage_add_meta_box() {
    $screen = get_current_screen();

    if ( $screen && $screen->id === 'page' && isset( $_GET['post'] ) ) {
        $homepage_id = get_option( 'page_on_front' );
        $current_post_id = intval( $_GET['post'] );

        if ( $current_post_id === intval( $homepage_id ) ) {
            add_meta_box(
                'smart_homepage_settings',     // ID
                'Hero section',                // Title
                'smart_homepage_render_box',   // Callback
                'page',                        // Screen
                'normal',                      // Context
                'high'                         // Priority
            );
        }
    }
}

function smart_homepage_render_box( $post ) {

    // Security nonce
    wp_nonce_field( 'smart_homepage_meta_nonce_action', 'smart_homepage_meta_nonce' );

    // Load values
    $hero_title = get_post_meta( $post->ID, '_hero_title', true );
    $hero_description = get_post_meta( $post->ID, '_hero_description', true );
    $badge1_number    = get_post_meta( $post->ID, '_badge1_number', true );
    $badge1_text      = get_post_meta( $post->ID, '_badge1_text', true );
    $badge2_number    = get_post_meta( $post->ID, '_badge2_number', true );
    $badge2_text      = get_post_meta( $post->ID, '_badge2_text', true );

    // Title field - use textarea so editors can press Enter for line breaks
    ?>
   <p>
  <label for="hero_title"><strong>Hero Title</strong></label><br>

  <?php
  $editor_id = 'hero_title';
  $settings = array(
      'textarea_name' => 'hero_title',   // IMPORTANT: name used in $_POST
      'textarea_rows' => 3,
      'media_buttons' => false,
      'teeny'         => true,           // simple toolbar
      'tinymce'       => array( 'wpautop' => false ), // try to avoid automatic <p>
      'quicktags'     => true,
      'wpautop'       => false,
  );

  wp_editor( $hero_title, $editor_id, $settings );
  ?>
   </p>

    <p>
        <label for="hero_description"><strong>Hero Description</strong></label><br>
        <?php
        // wp_editor settings: textarea_name must be hero_description so $_POST uses that name
        $editor_id = 'hero_description';
        $settings = array(
            'textarea_name' => 'hero_description',
            'media_buttons' => true,
            'textarea_rows' => 6,
            'teeny'         => false,
        );
        wp_editor( $hero_description, $editor_id, $settings );
        ?>
    </p>

    <h4>Badge 1</h4>
    <p>
      <label for="badge1_number">Number</label><br>
      <input type="text" name="badge1_number" id="badge1_number" value="<?php echo esc_attr( $badge1_number ); ?>" placeholder="e.g. 10+">
      <br><br>
      <label for="badge1_text">Text</label><br>
      <textarea name="badge1_text" id="badge1_text" rows="2" style="width:100%;"><?php echo esc_textarea( $badge1_text ); ?></textarea>
      <small class="description">Press Enter for a line break (will be rendered as &lt;br&gt; on the site).</small>
    </p>

    <h4>Badge 2</h4>
    <p>
      <label for="badge2_number">Number</label><br>
      <input type="text" name="badge2_number" id="badge2_number" value="<?php echo esc_attr( $badge2_number ); ?>" placeholder="e.g. 100+">
      <br><br>
      <label for="badge2_text">Text</label><br>
      <textarea name="badge2_text" id="badge2_text" rows="2" style="width:100%;"><?php echo esc_textarea( $badge2_text ); ?></textarea>
      <small class="description">Press Enter for a line break (will be rendered as &lt;br&gt; on the site).</small>
    </p>
    <?php
}

/* ---------------------------
 * Save meta box data
 * --------------------------- */
add_action( 'save_post', 'smart_homepage_save_meta_box' );
function smart_homepage_save_meta_box( $post_id ) {
    // Verify nonce
    if ( ! isset( $_POST['smart_homepage_meta_nonce'] ) ||
         ! wp_verify_nonce( $_POST['smart_homepage_meta_nonce'], 'smart_homepage_meta_nonce_action' ) ) {
        return;
    }

    // Do not save during autosave
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }

    // Capability check
    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    // Only save when editing the homepage
    $homepage_id = get_option( 'page_on_front' );
    if ( intval( $post_id ) !== intval( $homepage_id ) ) {
        return;
    }

    // Save hero title (preserve newlines)
    if ( isset( $_POST['hero_title'] ) ) {
    $raw = wp_unslash( $_POST['hero_title'] );
    $clean = wp_kses_post( $raw );
    update_post_meta( $post_id, '_hero_title', $clean );

}

    // Save hero description (allow safe HTML)
    if ( isset( $_POST['hero_description'] ) ) {
        // wp_kses_post allows same tags as post content
        $desc = wp_kses_post( wp_unslash( $_POST['hero_description'] ) );
        update_post_meta( $post_id, '_hero_description', $desc );
    } else {
        delete_post_meta( $post_id, '_hero_description' );
    }

    // Badges: numbers (single-line) and text (multi-line)
    if ( isset( $_POST['badge1_number'] ) ) {
        update_post_meta( $post_id, '_badge1_number', sanitize_text_field( wp_unslash( $_POST['badge1_number'] ) ) );
    } else {
        delete_post_meta( $post_id, '_badge1_number' );
    }

    if ( isset( $_POST['badge1_text'] ) ) {
        $b1 = sanitize_textarea_field( wp_unslash( $_POST['badge1_text'] ) );
        update_post_meta( $post_id, '_badge1_text', $b1 );
    } else {
        delete_post_meta( $post_id, '_badge1_text' );
    }

    if ( isset( $_POST['badge2_number'] ) ) {
        update_post_meta( $post_id, '_badge2_number', sanitize_text_field( wp_unslash( $_POST['badge2_number'] ) ) );
    } else {
        delete_post_meta( $post_id, '_badge2_number' );
    }

    if ( isset( $_POST['badge2_text'] ) ) {
        $b2 = sanitize_textarea_field( wp_unslash( $_POST['badge2_text'] ) );
        update_post_meta( $post_id, '_badge2_text', $b2 );
    } else {
        delete_post_meta( $post_id, '_badge2_text' );
    }
}

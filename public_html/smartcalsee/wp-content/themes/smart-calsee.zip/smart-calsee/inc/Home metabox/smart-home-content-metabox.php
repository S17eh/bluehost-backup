<?php 

add_action( 'add_meta_boxes', 'smart_contact_add_meta_box' );
function smart_contact_add_meta_box() {
    $screen = get_current_screen();

    if ( $screen && $screen->id === 'page' && isset( $_GET['post'] ) ) {
        $homepage_id = get_option( 'page_on_front' );
        $current_post_id = intval( $_GET['post'] );

        if ( $current_post_id === intval( $homepage_id ) ) {
            add_meta_box(
                'smart_contact_settings',     // ID
                'Contact section',            // Title
                'smart_contact_render_box',   // Callback
                'page',                       // Screen
                'normal',                     // Context
                'high'                        // Priority
            );
        }
    }
}

function smart_contact_render_box( $post ) {
    wp_nonce_field( 'smart_contact_meta_nonce_action', 'smart_contact_meta_nonce' );

    $contact_title       = get_post_meta( $post->ID, '_contact_home_title', true );
    $contact_description = get_post_meta( $post->ID, '_contact_home_description', true );
    $button_text         = get_post_meta( $post->ID, '_contact_button_text', true );
    $button_link         = get_post_meta( $post->ID, '_contact_button_link', true );
    ?>
    <p>
        <label for="contact-title"><strong>Contact Title</strong></label><br>
        <input type="text" name="contact_home_title" id="contact-title" value="<?php echo esc_attr( $contact_title ); ?>" style="width:100%;">
    </p>

    <p>
        <label for="contact-description"><strong>Contact Description</strong></label><br>
        <?php
        // Classic editor field
        $editor_id = 'contact-description';
        $settings = array(
            'textarea_name' => 'contact_home_description',
            'media_buttons' => true,
            'textarea_rows' => 6,
            'teeny'         => false,
        );
        wp_editor( $contact_description, $editor_id, $settings );
        ?>
    </p>

    <hr>

    <h4>Button Settings</h4>
    <p>
        <label for="contact-button-text"><strong>Button Text</strong></label><br>
        <input type="text" name="contact_button_text" id="contact-button-text" value="<?php echo esc_attr( $button_text ); ?>" style="width:100%;">
    </p>

    <p>
        <label for="contact-button-link"><strong>Button Link</strong></label><br>
        <input type="url" name="contact_button_link" id="contact-button-link" value="<?php echo esc_attr( $button_link ); ?>" style="width:100%;">
    </p>
    <?php
}

/**
 * Save meta box data
 */
add_action( 'save_post', 'smart_contact_save_meta_box' );
function smart_contact_save_meta_box( $post_id ) {
    // Verify nonce
    if ( ! isset( $_POST['smart_contact_meta_nonce'] ) ||
         ! wp_verify_nonce( $_POST['smart_contact_meta_nonce'], 'smart_contact_meta_nonce_action' ) ) {
        return;
    }

    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    if ( isset( $_POST['contact_home_title'] ) ) {
        update_post_meta( $post_id, '_contact_home_title', sanitize_text_field( wp_unslash( $_POST['contact_home_title'] ) ) );
    }

    if ( isset( $_POST['contact_home_description'] ) ) {
        $desc = wp_kses_post( wp_unslash( $_POST['contact_home_description'] ) );
        update_post_meta( $post_id, '_contact_home_description', $desc );
    }

    if ( isset( $_POST['contact_button_text'] ) ) {
        update_post_meta( $post_id, '_contact_button_text', sanitize_text_field( wp_unslash( $_POST['contact_button_text'] ) ) );
    }

    if ( isset( $_POST['contact_button_link'] ) ) {
        update_post_meta( $post_id, '_contact_button_link', esc_url_raw( wp_unslash( $_POST['contact_button_link'] ) ) );
    }
}

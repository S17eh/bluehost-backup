<?php
/**
 * Meta Box: Why Choose Section (with repeaters for stats + buttons)
 */

add_action( 'add_meta_boxes', 'smart_why_add_metabox' );
function smart_why_add_metabox() {
    $screen = get_current_screen();
    if ( ! $screen ) return;

    if ( $screen->id === 'page' && isset( $_GET['post'] ) ) {
        $homepage_id = get_option( 'page_on_front' );
        $current_post_id = intval( $_GET['post'] );

        // Only show on homepage edit screen
        if ( $current_post_id === intval( $homepage_id ) ) {
            add_meta_box(
                'smart_why_box',
                'Why Choose Section',
                'smart_why_render_box',
                'page',
                'normal',
                'high'
            );
        }
    }
}

/**
 * Render the meta box
 */
function smart_why_render_box( $post ) {
    wp_nonce_field( 'smart_why_nonce_action', 'smart_why_nonce' );

    // Load saved data
    $title   = get_post_meta( $post->ID, '_smart_why_title', true );
    $desc    = get_post_meta( $post->ID, '_smart_why_description', true );
    $stats   = get_post_meta( $post->ID, '_smart_why_stats', true );
    $buttons = get_post_meta( $post->ID, '_smart_why_buttons', true );

    if ( ! is_array( $stats ) ) $stats = [];
    if ( ! is_array( $buttons ) ) $buttons = [];
    ?>

    <p>
        <label for="smart_why_title"><strong>why chooes Title</strong></label><br>
        <input type="text" name="smart_why_title" id="smart_why_title" value="<?php echo esc_attr( $title ); ?>" style="width:100%;">
    </p>

    <p>
        <label for="smart_why_description"><strong>Why chooes Description</strong></label><br>
        <?php
        wp_editor( $desc, 'smart_why_description', [
            'textarea_name' => 'smart_why_description',
            'media_buttons' => false,
            'textarea_rows' => 6,
            'teeny'         => false,
        ] );
        ?>
    </p>

    <hr>

    <!-- Stats Repeater -->
    <h4>Stats (Repeatable)</h4>
    <div id="smart_why_stats_wrap">
        <?php
        if ( empty( $stats ) ) $stats = [ [ 'num' => '', 'label' => '' ] ];
        foreach ( $stats as $s ) :
            $num = isset( $s['num'] ) ? $s['num'] : '';
            $lbl = isset( $s['label'] ) ? $s['label'] : '';
        ?>
        <div class="smart_why_stat_row" style="display:flex; gap:8px; margin-bottom:8px;">
            <input type="text" name="smart_why_stats_num[]" placeholder="Number (e.g. 10+)" value="<?php echo esc_attr( $num ); ?>" style="width:30%;">
            <input type="text" name="smart_why_stats_lbl[]" placeholder="Label (e.g. Years of Expertise)" value="<?php echo esc_attr( $lbl ); ?>" style="width:60%;">
            <button type="button" class="button smart_why_remove_stat" style="width:8%;">Remove</button>
        </div>
        <?php endforeach; ?>
    </div>
    <p><button type="button" class="button" id="smart_why_add_stat">Add</button></p>

    <hr>

    <!-- Buttons Repeater -->
    <h4>Buttons (Repeatable)</h4>
    <div id="smart_why_buttons_wrap">
        <?php
        if ( empty( $buttons ) ) $buttons = [ [ 'text' => '', 'link' => '' ] ];
        foreach ( $buttons as $b ) :
            $text = isset( $b['text'] ) ? $b['text'] : '';
            $link = isset( $b['link'] ) ? $b['link'] : '';
        ?>
        <div class="smart_why_button_row" style="display:flex; gap:8px; margin-bottom:8px;">
            <input type="text" name="smart_why_buttons_text[]" placeholder="Button Text" value="<?php echo esc_attr( $text ); ?>" style="width:40%;">
            <input type="url"  name="smart_why_buttons_link[]" placeholder="Button Link" value="<?php echo esc_attr( $link ); ?>" style="width:50%;">
            <button type="button" class="button smart_why_remove_button" style="width:8%;">Remove</button>
        </div>
        <?php endforeach; ?>
    </div>
    <p><button type="button" class="button" id="smart_why_add_button">Add</button></p>

    <script type="text/javascript">
    (function($){
        // Add Stat
        $('#smart_why_add_stat').on('click', function(e){
            e.preventDefault();
            var tpl = '<div class="smart_why_stat_row" style="display:flex; gap:8px; margin-bottom:8px;">' +
                      '<input type="text" name="smart_why_stats_num[]" placeholder="Number (e.g. 10+)" value="" style="width:30%;">' +
                      '<input type="text" name="smart_why_stats_lbl[]" placeholder="Label (e.g. Years of Expertise)" value="" style="width:60%;">' +
                      '<button type="button" class="button smart_why_remove_stat" style="width:8%;">Remove</button>' +
                      '</div>';
            $('#smart_why_stats_wrap').append(tpl);
        });

        // Remove Stat
        $(document).on('click', '.smart_why_remove_stat', function(e){
            e.preventDefault();
            $(this).closest('.smart_why_stat_row').remove();
            if ($('#smart_why_stats_wrap .smart_why_stat_row').length === 0) {
                $('#smart_why_add_stat').trigger('click');
            }
        });

        // Add Button
        $('#smart_why_add_button').on('click', function(e){
            e.preventDefault();
            var tpl = '<div class="smart_why_button_row" style="display:flex; gap:8px; margin-bottom:8px;">' +
                      '<input type="text" name="smart_why_buttons_text[]" placeholder="Button Text" value="" style="width:40%;">' +
                      '<input type="url"  name="smart_why_buttons_link[]" placeholder="Button Link" value="" style="width:50%;">' +
                      '<button type="button" class="button smart_why_remove_button" style="width:8%;">Remove</button>' +
                      '</div>';
            $('#smart_why_buttons_wrap').append(tpl);
        });

        // Remove Button
        $(document).on('click', '.smart_why_remove_button', function(e){
            e.preventDefault();
            $(this).closest('.smart_why_button_row').remove();
            if ($('#smart_why_buttons_wrap .smart_why_button_row').length === 0) {
                $('#smart_why_add_button').trigger('click');
            }
        });
    })(jQuery);
    </script>

    <?php
}

/**
 * Save meta box
 */
add_action( 'save_post', 'smart_why_save_meta' );
function smart_why_save_meta( $post_id ) {
    // Verify nonce
    if ( ! isset( $_POST['smart_why_nonce'] ) ||
         ! wp_verify_nonce( $_POST['smart_why_nonce'], 'smart_why_nonce_action' ) ) {
        return;
    }

    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    // Title
    if ( isset( $_POST['smart_why_title'] ) ) {
        update_post_meta( $post_id, '_smart_why_title', sanitize_text_field( wp_unslash( $_POST['smart_why_title'] ) ) );
    }

    // Description
    if ( isset( $_POST['smart_why_description'] ) ) {
        $desc = wp_kses_post( wp_unslash( $_POST['smart_why_description'] ) );
        update_post_meta( $post_id, '_smart_why_description', $desc );
    }

    // Stats repeater
    $nums = isset( $_POST['smart_why_stats_num'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['smart_why_stats_num'] ) ) : [];
    $lbls = isset( $_POST['smart_why_stats_lbl'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['smart_why_stats_lbl'] ) ) : [];

    $stats = [];
    $count = max( count( $nums ), count( $lbls ) );
    for ( $i = 0; $i < $count; $i++ ) {
        $num = $nums[$i] ?? '';
        $lbl = $lbls[$i] ?? '';
        if ( $num === '' && $lbl === '' ) continue;
        $stats[] = [ 'num' => $num, 'label' => $lbl ];
    }
    if ( ! empty( $stats ) ) update_post_meta( $post_id, '_smart_why_stats', $stats );
    else delete_post_meta( $post_id, '_smart_why_stats' );

    // Buttons repeater
    $texts = isset( $_POST['smart_why_buttons_text'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['smart_why_buttons_text'] ) ) : [];
    $links = isset( $_POST['smart_why_buttons_link'] ) ? array_map( 'esc_url_raw', wp_unslash( $_POST['smart_why_buttons_link'] ) ) : [];

    $buttons = [];
    $countb = max( count( $texts ), count( $links ) );
    for ( $j = 0; $j < $countb; $j++ ) {
        $t = $texts[$j] ?? '';
        $l = $links[$j] ?? '';
        if ( $t === '' && $l === '' ) continue;
        $buttons[] = [ 'text' => $t, 'link' => $l ];
    }
    if ( ! empty( $buttons ) ) update_post_meta( $post_id, '_smart_why_buttons', $buttons );
    else delete_post_meta( $post_id, '_smart_why_buttons' );
}

<?php 

add_action( 'add_meta_boxes', 'smart_service_add_meta_box' );
function smart_service_add_meta_box() {
    $screen = get_current_screen();

    if ( $screen && $screen->id === 'page' && isset( $_GET['post'] ) ) {
        $homepage_id = get_option( 'page_on_front' );
        $current_post_id = intval( $_GET['post'] );

        if ( $current_post_id === intval( $homepage_id ) ) {
            add_meta_box(
                'smart_service_settings',     // ID
                'Service section',                // Title
                'smart_service_render_box',   // Callback
                'page',                        // Screen
                'normal',                      // Context
                'high'                         // Priority
            );
        }
    }
}

function smart_service_render_box( $post ) {
    // Security nonce
    wp_nonce_field( 'smart_service_meta_nonce_action', 'smart_service_meta_nonce' );

    // Load values
    $hero_title = get_post_meta( $post->ID, '_service_title', true );
    $service_description = get_post_meta( $post->ID, '_service_description', true );

    // Title field
    ?>
    <p>
        <label for="service-title"><strong>Hero Title</strong></label><br>
        <input type="text" name="service_title" id="service-title" value="<?php echo esc_attr( $hero_title ); ?>" style="width:100%;">
    </p>

    <p>
        <label for="service-description"><strong>Hero Description</strong></label><br>
        <?php
        // wp_editor settings: textarea_name must be hero_description so $_POST uses that name
        $editor_id = 'service-description';
        $settings = array(
            'textarea_name' => 'service_description',
            'media_buttons' => true,
            'textarea_rows' => 6,
            'teeny'         => false,
        );
        wp_editor( $service_description, $editor_id, $settings );
        ?>
    </p>
    <?php
}


add_action( 'save_post', 'smart_service_save_meta_box' );
function smart_service_save_meta_box( $post_id ) {
    // Verify nonce
    if ( ! isset( $_POST['smart_service_meta_nonce'] ) ||
         ! wp_verify_nonce( $_POST['smart_service_meta_nonce'], 'smart_service_meta_nonce_action' ) ) {
        return;
    }

    // Do not save during autosave
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }

    // Capability check
    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    // Save hero title
    if ( isset( $_POST['service_title'] ) ) {
        update_post_meta( $post_id, '_service_title', sanitize_text_field( wp_unslash( $_POST['service_title'] ) ) );
    }

    // Save hero description (allow safe HTML)
    if ( isset( $_POST['service_description'] ) ) {
        // wp_kses_post allows same tags as post content
        $desc = wp_kses_post( wp_unslash( $_POST['service_description'] ) );
        update_post_meta( $post_id, '_service_description', $desc );
    }
}

<?php

/**
 * The header for our theme
 *
 * Displays the <head> section and everything up until <div id="content">
 *
 * @package Smart-Calsee
 */
?>
<!doctype html>
<html <?php language_attributes(); ?>>

<head>
  <meta charset="<?php bloginfo('charset'); ?>" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="profile" href="https://gmpg.org/xfn/11">
  <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

  <div id="page" class="site">

        <header id="masthead" class="site-header">
          <!-- Bootstrap Navbar -->
          <nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top shadow-sm" id="siteHeader" style="border-radius: 50px; margin: 26px 60px 0px 60px; border: 1px solid #DFDFDF;">
            <div class="container-fluid">

              <!-- Logo / Brand -->
              <div class="navbar-brand ms-sm-3 d-flex align-items-center">
                <?php
                if (function_exists('the_custom_logo') && has_custom_logo()) {
                  the_custom_logo();
                } else {
                  $home_url  = esc_url(home_url('/'));
                  $site_name = get_bloginfo('name');
                  $logo_src  = get_template_directory_uri() . '/image/Logo.png';
                ?>
                  <a class="d-flex align-items-center" href="<?php echo $home_url; ?>">
                    <img src="<?php echo esc_url($logo_src); ?>" alt="<?php echo esc_attr($site_name); ?>" style="height:28px;">
                  </a>
                <?php } ?>
              </div>

              <button class="navbar-toggler me-sm-3 border-0" type="button"
                data-bs-toggle="collapse" data-bs-target="#primaryNavbar"
                aria-controls="primaryNavbar" aria-expanded="false"
                aria-label="<?php esc_attr_e('Toggle navigation', 'smart-calsee'); ?>">

                <span class="open-icon">
                  <i class="bi bi-list"></i> <!-- Bootstrap hamburger icon -->
                </span>
                <span class="close-icon d-none">
                  <i class="bi bi-x-lg"></i> <!-- Bootstrap close icon -->
                </span>
              </button>

              <div class="collapse navbar-collapse navbar-menu-custom" id="primaryNavbar">
                <?php
                wp_nav_menu(array(
                  'theme_location' => 'primary',
                  'container'      => false,
                  'menu_class'     => 'navbar-nav mx-auto',
                  'fallback_cb'    => 'wp_page_menu',
                  'depth'          => 2,
                ));
                ?>

                <!-- Country selector (static) -->
                <?php
                // Get all service categories
                $terms = get_terms(array(
                  'taxonomy'   => 'service_category',
                  'hide_empty' => false,
                  'orderby'    => 'name',
                  'order'      => 'ASC',
                ));

                // Default category name
                $default_cat = 'Australia';
                ?>

                <div class="country-select position-relative">
                  <button id="country-toggle" class="country-btn d-flex align-items-center justify-content-between w-100" type="button">
                    <?php
                    // Find default category image
                    $default_img = '';
                    $default_link = '';
                    $default_label = '';
                    foreach ($terms as $term) {
                      if (strtolower($term->name) === strtolower($default_cat)) {
                        $img_id = get_term_meta($term->term_id, '_service_cat_image_id', true);
                        $default_img = $img_id ? wp_get_attachment_image_url($img_id, 'thumbnail') : '';
                        $default_link = get_term_link($term);
                        $default_label = $term->name;
                      }
                    }
                    ?>
                    <span class="d-flex align-items-center">
                      <?php if ($default_img) : ?>
                        <img id="selected-flag" src="<?php echo esc_url($default_img); ?>" alt="flag" class="flag-icon me-2">
                      <?php else : ?>
                        <span id="selected-flag" class="me-2">🌏</span>
                      <?php endif; ?>
                      <span id="selected-label" class="fw-medium"><?php echo esc_html($default_label ?: 'Select Country'); ?></span>
                    </span>
                    <span class="dropdown-arrow ms-2">
                      <img src="<?php echo get_template_directory_uri(); ?>/assets/image/arrow-down.svg" alt="arrow" class="arrow-icon">
                    </span>
                  </button>

                  <ul id="country-dropdown" class="dropdown-list list-unstyled m-0 p-2 shadow-sm">
                    <?php foreach ($terms as $t) :
                      $img_id = get_term_meta($t->term_id, '_service_cat_image_id', true);
                      $img_url = $img_id ? wp_get_attachment_image_url($img_id, 'thumbnail') : '';
                      $term_link = get_term_link($t);
                    ?>
                      <li class="dropdown-item d-flex align-items-center p-2" data-url="<?php echo esc_url($term_link); ?>" data-name="<?php echo esc_attr($t->name); ?>" data-img="<?php echo esc_url($img_url); ?>">
                        <?php if ($img_url) : ?>
                          <img src="<?php echo esc_url($img_url); ?>" class="flag-icon me-2" alt="">
                        <?php endif; ?>
                        <?php echo esc_html(strtoupper($t->name)); ?>
                      </li>
                    <?php endforeach; ?>
                  </ul>
                </div>

              </div>
            </div>
          </nav>
        </header>

        <div id="wrapper">
          <div id="content">
            <div class="scroll"></div>
// mobile menu toogle icon
document.addEventListener("DOMContentLoaded", function () {
  const toggler = document.querySelector(".navbar-toggler");
  const openIcon = toggler.querySelector(".open-icon");
  const closeIcon = toggler.querySelector(".close-icon");

  toggler.addEventListener("click", function () {
    const expanded = this.getAttribute("aria-expanded") === "true";
    openIcon.classList.toggle("d-none", expanded);
    closeIcon.classList.toggle("d-none", !expanded);
  });
});
// country dropdwon
document.addEventListener("DOMContentLoaded", function(){
  const toggle = document.getElementById("country-toggle");
  const dropdown = document.getElementById("country-dropdown");
  const flag = document.getElementById("selected-flag");
  const label = document.getElementById("selected-label");

  toggle.addEventListener("click", () => {
    dropdown.classList.toggle("show-dropdown");
  });

  dropdown.querySelectorAll(".dropdown-item").forEach(item => {
    item.addEventListener("click", () => {
      const name = item.getAttribute("data-name");
      const img = item.getAttribute("data-img");
      const url = item.getAttribute("data-url");

      label.textContent = name.toUpperCase();
      if (img) {
        flag.outerHTML = '<img id="selected-flag" src="'+img+'" class="flag-icon me-2" alt="">';
      } else {
        flag.outerHTML = '<span id="selected-flag" class="me-2">🌏</span>';
      }

      dropdown.classList.remove("show-dropdown");

      // Navigate to selected category
      if (url) window.location.href = url;
    });
  });

  // Close when clicking outside
  document.addEventListener("click", e => {
    if (!toggle.contains(e.target) && !dropdown.contains(e.target)) {
      dropdown.classList.remove("show-dropdown");
    }
  });
});
 
 /*------------------------------
  Register plugins
  ------------------------------*/
  gsap.registerPlugin(ScrollTrigger, ScrollSmoother);
  const content = document.querySelector('#content') || document.body;

  /*------------------------------
  Making some circles noise
  ------------------------------*/
  // Render background "noise" circles only when a host is present
  const noiseHost = document.querySelector('.scroll');
  let Circles = [];
  if (noiseHost) {
    const simplex = new SimplexNoise();
    for (let i = 0; i < 5000; i++) {
      const div = document.createElement('div');
      div.classList.add('circle');
      const n1 = simplex.noise2D(i * 0.003, i * 0.0033);
      const n2 = simplex.noise2D(i * 0.002, i * 0.001);

      // const style = {
      //   transform: `translate(${n2 * 200}px) rotate(${n2 * 270}deg) scale(${3 + n1 * 2}, ${3 + n2 * 2})`,
      //   boxShadow: `0 0 0 .2px hsla(${Math.floor(i * 0.3)}, 70%, 70%, .6)`
      // };

      // Object.assign(div.style, style);
      noiseHost.appendChild(div);
    }
    Circles = noiseHost.querySelectorAll('.circle');
  }

  /*------------------------------
  Init ScrollSmoother (with mobile detection)
  ------------------------------*/
  let scrollerSmoother;

  // Check if device is mobile/tablet
  const isMobile = window.innerWidth <= 768 || /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

  if (!isMobile) {
    const hasSmootherDOM = !!document.querySelector('#wrapper') && !!document.querySelector('#content');
    if (hasSmootherDOM) {
      scrollerSmoother = ScrollSmoother.create({
        content: '#content',
        wrapper: '#wrapper',
        smooth: 1,
        effects: false
      });
    } else {
      scrollerSmoother = null; // fall back to native scroll; sticky header uses window scrollY
    }
  }


  /*------------------------------
  Scroll Trigger (with mobile optimization)
  ------------------------------*/
  const main = gsap.timeline({
    scrollTrigger: {
      scrub: isMobile ? 0.3 : 0.7, // Less scrub on mobile for better performance
      start: "top 25%",
      end: "bottom bottom",
      invalidateOnRefresh: true, // Recalculate on resize
      refreshPriority: -1 // Lower priority for better performance
    }
  });

  if (Circles && Circles.length) {
    Circles.forEach(circle => {
      main.to(circle, {
        opacity: 1,
        ease: isMobile ? "none" : "power2.out"
      });
    });
  }


  const buttonsData = [
    'AC', 'CE', '%', '÷',
    '7', '8', '9', '×',
    '4', '5', '6', '-',
    '1', '2', '3', '+',
    '0', '00', '.', '='
  ];

  const buttonsContainer = document.getElementById('buttons');
  const display = document.getElementById('display');
  const calculator = document.getElementById('calculator');
  const siteHeader = document.getElementById('siteHeader');
  const nav = document.getElementById('menu');


  // Toggle navbar 'stuck' class when it hits the very top
  const headerEl = siteHeader;
  const updateNavbarStuck = () => {
    if (!headerEl) return;
    const isAtTop = window.scrollY > 0;
    headerEl.classList.toggle('stuck', isAtTop);
  };
  updateNavbarStuck();
  window.addEventListener('scroll', updateNavbarStuck, { passive: true });

  // Measure sticky elements and expose heights as CSS variables
  const setStickyHeights = () => {
    const root = document.documentElement;
    const headerH = siteHeader ? siteHeader.offsetHeight : 0;
    const menuH = nav ? nav.offsetHeight : 0;
    root.style.setProperty('--site-header-h', headerH + 'px');
    root.style.setProperty('--services-menu-h', menuH + 'px');
  };
  setStickyHeights();
  window.addEventListener('resize', setStickyHeights);

  const getButtonDimensions = () => {
    const screenWidth = window.innerWidth;
    
    if (screenWidth <= 480) {
      // Mobile phones
      return {
        btnWidth: 46,
        btnHeight: 46,
        gap: 14,
        displayOffsetY: 130
      };
    } else if (screenWidth <= 768) {
      // Tablets
      return {
        btnWidth: 52,
        btnHeight: 52,
        gap: 16,
        displayOffsetY: 80
      };
    } else {
      // Desktop
      return {
        btnWidth: 56,
        btnHeight: 56,
        gap: 18,
        displayOffsetY: 130
      };
    }
  };

  let { btnWidth, btnHeight, gap, displayOffsetY } = getButtonDimensions();
  const positions = [];
  const base = (typeof ThemeData !== 'undefined' && ThemeData.assetsUrl) ? ThemeData.assetsUrl : '/wp-content/themes/smart-calsee/assets/image/';

  const imageMap = {
  'AC': base + 'group-ac.png',
  'CE': base + 'group-ce.png',
  '%': base + 'percentage.png',
  '÷': base + 'group-divide.png',
  '×': base + 'group-x.png',
  '+': base + 'group-plus.png',
  '-': base + 'group-minus.png',
  '=': base + 'group-equal.png',
  '.': base + 'group-dot.png',
  '1': base + 'group-1.png',
  '2': base + 'group-2.png',
  '3': base + 'group-3.png',
  '4': base + 'group-4.png',
  '5': base + 'group-5.png',
  '6': base + 'group-6.png',
  '7': base + 'group-7.png',
  '8': base + 'group-8.png',
  '9': base + 'group-9.png',
  '0': base + 'group-0.png',
  '00': base + 'group-00.png'
};

  // Build buttons (text-based like screenshot)
  // Map labels to image paths
  // const imageMap = {
  //   'AC': 'image/Group (AC).png',
  //   'CE': 'image/Group (CE).png',
  //   '%': 'image/Group (pecentage).png',
  //   '÷': 'image/Group (divide).png',
  //   '×': 'image/Group (x).png',
  //   '+': 'image/Group (plus).png',
  //   '-': 'image/Group (minus).png',
  //   '=': 'image/Group (equal).png',
  //   '.': 'image/Group (dot).png',
  //   '1': 'image/Group (1).png',
  //   '2': 'image/Group (2).png',
  //   '3': 'image/Group (3).png',
  //   '4': 'image/Group (4).png',
  //   '5': 'image/Group (5).png',
  //   '6': 'image/Group (6).png',
  //   '7': 'image/Group (7).png',
  //   '8': 'image/Group (8).png',
  //   '9': 'image/Group (9).png',
  //   '0': 'image/Group (0).png',
  //   '00': 'image/Group (10).png'
  // };

  buttonsData.forEach((label, index) => {
  const btn = document.createElement('button');
  btn.classList.add('btn');

  const imgSrc = imageMap[label];
  if (imgSrc) {
    const img = document.createElement('img');
    img.src = imgSrc;
    img.alt = label;
    btn.appendChild(img);
  } else {
    btn.textContent = label; // fallback if image missing
  }

  // Assign classes
  const isOperator = ['+', '-', '×', '÷', '%'].includes(label);
  const isCtrl = ['AC', 'CE'].includes(label);
  if (!isOperator && !isCtrl && label !== '=') btn.classList.add('number');
  if (isOperator) btn.classList.add('operator');
  if (label === '=') btn.classList.add('equal');
  if (label === 'AC') btn.classList.add('clear');
  if (isCtrl) btn.classList.add('ctrl');

  const row = Math.floor(index / 4);
  const col = index % 4;
  const x = col * (btnWidth + gap);
  const y = displayOffsetY + row * (btnHeight + gap);
  positions.push({ x, y });

  // Random initial scatter position
  btn.style.left = `${Math.random() * window.innerWidth}px`;
  btn.style.top = `${Math.random() * window.innerHeight}px`;

    // Click behavior
    btn.addEventListener('click', () => {
      if (label === 'AC') {
          display.value = '';
      } else if (label === 'CE') {
          display.value = display.value.slice(0, -1);
      } else if (label === '=') {
          try {
          let expr = display.value
              .replace(/×/g, '*')
              .replace(/÷/g, '/')
              .replace(/%/g, '/100');  // ✅ convert percent to division
          display.value = eval(expr);
          } catch {
          display.value = 'Error';
          }
      } else if (label === '00') {
          display.value += '00';
      } else {
          display.value += label;
      }
  });

    buttonsContainer.appendChild(btn);
  });

  // Animate into calculator grid (with mobile optimization)
  gsap.registerPlugin(ScrollTrigger);

  const buttons = gsap.utils.toArray('.btn');
  buttons.forEach((btn, i) => {
    const { x, y } = positions[i];
    
    // Different animation approach for mobile
    if (isMobile) {
      // Simpler animation for mobile - just fade in and position
      gsap.to(btn, {
        opacity: 1,
        top: () => calculator.offsetTop + y,
        left: () => calculator.offsetLeft + x + 32,
        duration: 0.5,
        delay: i * 0.05,
        scrollTrigger: {
          trigger: ".calculator",
          start: "top 80%",
          end: "top 20%",
          toggleActions: "play none none reverse"
        }
      });
    } else {
      // Full animation for desktop
      gsap.to(btn, {
        top: () => calculator.offsetTop + y,
        left: () => calculator.offsetLeft + x + 32,
        ease: "power2.out",
        scrollTrigger: {
          trigger: ".calculator",
          start: "top bottom",
          end: "top 30%",
          scrub: 4
        }
      });
    }
  });



  // Refresh ScrollTrigger on orientation change (mobile/tablet)
  window.addEventListener('orientationchange', () => {
    setTimeout(() => {
      ScrollTrigger.refresh();
      if (scrollerSmoother) {
        scrollerSmoother.refresh();
      }
    }, 100);
  });

  // Refresh on window resize for better mobile handling
  let resizeTimeout;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(() => {
      ScrollTrigger.refresh();
      if (scrollerSmoother) {
        scrollerSmoother.refresh();
      }
    }, 250);
  });



  /* rotating globe theme (only if container exists) */
  (function() {
    const container = document.querySelector('.globe-container');
    if (!container) return; // skip WebGL ribbon/globe when no container is on the page

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      45,
      (container.clientWidth || 600) / (container.clientHeight || 420),
      0.1,
      1000
    );
    camera.position.z = 3;

    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setPixelRatio(window.devicePixelRatio || 1);
    renderer.setSize(container.clientWidth || 600, container.clientHeight || 420);
    container.appendChild(renderer.domElement);

    // Lighting
    const light = new THREE.AmbientLight(0xffffff, 1.2);
    scene.add(light);

    // Load local image texture
    const textureLoader = new THREE.TextureLoader();
    const globeBase = (typeof ThemeData !== 'undefined' && ThemeData.assetsUrl)
      ? ThemeData.assetsUrl
      : '/wp-content/themes/smart-calsee/assets/image/';
    const texture = textureLoader.load(globeBase + 'mask_group.png');

    // Material
    const material = new THREE.MeshPhongMaterial({
      map: texture,
      transparent: true,
      opacity: 0.9,
      side: THREE.DoubleSide
    });

    // Half-sphere geometry
    const geometry = new THREE.SphereGeometry(
      1, 64, 64, 0, Math.PI * 2, 0, Math.PI / 2
    );

    const globe = new THREE.Mesh(geometry, material);
    scene.add(globe);

    // Animation loop
    function animate() {
      requestAnimationFrame(animate);
      globe.rotation.y += 0.005;
      renderer.render(scene, camera);
    }
    animate();

    // Responsive
    window.addEventListener("resize", () => {
      const width = container.clientWidth || 600;
      const height = container.clientHeight || 420;
      renderer.setSize(width, height);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
    });
  })();

  // Menu -> Card swipe + smooth scroll
  (function() {
    var menu = document.querySelector('.js-services-menu');
    if (!menu) return;

    var menuItems = Array.prototype.slice.call(menu.querySelectorAll('.menu-item'));
    var cards = Array.prototype.slice.call(document.querySelectorAll('.js-stack-cards__item'));

    // Build key maps
    var keyToCard = {};
    cards.forEach(function(card){
      var key = card.getAttribute('data-key');
      if (key) keyToCard[key] = card;
    });

    var headerEl = document.getElementById('siteHeader');
    var menuEl = document.querySelector('.js-services-menu');
    function getStickyOffset() {
      var h = headerEl ? headerEl.offsetHeight : 0;
      var m = menuEl ? menuEl.offsetHeight : 0;
      return h + m + 12; // small gap
    }

    function cardIndexByKey(key){
      for (var i=0;i<cards.length;i++){
        if (cards[i].getAttribute('data-key') === key) return i;
      }
      return -1;
    }

    function currentActiveKey(){
      var active = menu.querySelector('.menu-item.active');
      return active ? active.getAttribute('data-target') : null;
    }

    function setActiveMenu(key){
      menuItems.forEach(function(mi){ mi.classList.toggle('active', mi.getAttribute('data-target') === key); });
    }

    function smoothScrollTo(y){ 
      try {
        window.scrollTo({ top: y, behavior: 'smooth' });
      } catch(e) {
        window.scrollTo(0, y);
      }
    }

    function swipeIn(card, direction){
      if (!window.gsap || !card) return;
      // Kill any running tweens on child parts to avoid conflicts
      gsap.killTweensOf(card);

      // Try to split animation between text and image blocks for a nicer effect
      var textBlock = card.querySelector('.card-content');
      var imageEl = card.querySelector('img');
      var imageBlock = imageEl ? imageEl.closest('.col-12') || imageEl.parentElement : null;

      var tl = gsap.timeline();
      if (textBlock && imageBlock) {
        gsap.killTweensOf([textBlock, imageBlock]);
        // Text from navigation direction, image from opposite
        var textFromX = direction * 80;
        var imageFromX = -direction * 80;
        tl.fromTo(textBlock, { x: textFromX, opacity: 0 }, { x: 0, opacity: 1, duration: 0.55, ease: 'power2.out' }, 0)
          .fromTo(imageBlock, { x: imageFromX, opacity: 0 }, { x: 0, opacity: 1, duration: 0.55, ease: 'power2.out' }, 0);
      } else {
        // Fallback: animate whole card
        tl.fromTo(card, { x: direction * 60, opacity: 0 }, { x: 0, opacity: 1, duration: 0.5, ease: 'power2.out' });
      }
    }

    var pendingObserver = null;
    var isNavigating = false;
    function runSwipeWhenInView(card, direction){
      if (!('IntersectionObserver' in window)) { swipeIn(card, direction); return; }
      if (pendingObserver) { try { pendingObserver.disconnect(); } catch(_){} }
      pendingObserver = new IntersectionObserver(function(entries){
        var en = entries && entries[0];
        if (!en) return;
        if (en.isIntersecting && en.intersectionRatio >= 0.55) {
          swipeIn(card, direction);
          try { pendingObserver.disconnect(); } catch(_){}
          pendingObserver = null;
          isNavigating = false;
          menu.classList.remove('is-busy');
        }
      }, { root: null, rootMargin: '-' + getStickyOffset() + 'px 0px 0px 0px', threshold: [0, 0.25, 0.55, 0.75, 1] });
      pendingObserver.observe(card);
    }

    function scrollToCardByKey(key){
      var card = keyToCard[key];
      if (!card) return;
      var targetY = window.scrollY + card.getBoundingClientRect().top - getStickyOffset();
      var prevKey = currentActiveKey();
      var dir = 1;
      if (prevKey){
        var fromIdx = cardIndexByKey(prevKey);
        var toIdx = cardIndexByKey(key);
        if (fromIdx > -1 && toIdx > -1) dir = toIdx > fromIdx ? 1 : -1;
      }
      isNavigating = true;
      menu.classList.add('is-busy');
      setActiveMenu(key);
      runSwipeWhenInView(card, dir);
      smoothScrollTo(targetY);
    }

    // Click handling
    menuItems.forEach(function(item){
      item.addEventListener('click', function(){
        if (isNavigating) return; // debounce rapid clicks
        var key = item.getAttribute('data-target');
        if (key) scrollToCardByKey(key);
      });
    });

    // Keep menu active in sync while scrolling by measuring visibility
    var ticking = false;
    function updateActiveOnScroll(){
      ticking = false;
      var offsetTop = getStickyOffset();
      var viewTop = offsetTop;
      var viewBottom = window.innerHeight;

      var bestKey = null;
      var bestVisible = -1;

      for (var i=0;i<cards.length;i++){
        var c = cards[i];
        var rect = c.getBoundingClientRect();
        var top = rect.top;
        var bottom = rect.bottom;
        var height = rect.height || 1;

        // visible height within viewport below the sticky region
        var visible = Math.max(0, Math.min(bottom, viewBottom) - Math.max(top, viewTop));
        if (visible > bestVisible){
          bestVisible = visible;
          bestKey = c.getAttribute('data-key');
        }
      }
      if (bestKey) setActiveMenu(bestKey);
    }

    function onScroll(){
      if (!ticking){
        ticking = true;
        window.requestAnimationFrame(updateActiveOnScroll);
      }
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    // initial sync
    updateActiveOnScroll();
  })();

  (function() {
    // Utility function for reduced motion detection
    function hasReducedMotion() {
      if(!window.matchMedia) return false;
      var matchMediaObj = window.matchMedia('(prefers-reduced-motion: reduce)');
      if(matchMediaObj) return matchMediaObj.matches;
      return false;
    }

    // Stacking Cards functionality
    var StackCards = function(element) {
      this.element = element;
      this.items = this.element.getElementsByClassName('js-stack-cards__item');
      this.scrollingFn = false;
      this.scrolling = false;
      initStackCardsEffect(this); 
      initStackCardsResize(this); 
    };

    function initStackCardsEffect(element) {
      setStackCards(element);
      var observer = new IntersectionObserver(stackCardsCallback.bind(element), { threshold: [0, 1] });
      observer.observe(element.element);
    }

    function initStackCardsResize(element) {
      element.element.addEventListener('resize-stack-cards', function(){
        setStackCards(element);
      });
    }
    
    function stackCardsCallback(entries) {
      if(entries[0].isIntersecting) {
        if(this.scrollingFn) return;
        stackCardsInitEvent(this);
      } else {
        if(!this.scrollingFn) return;
        window.removeEventListener('scroll', this.scrollingFn);
        this.scrollingFn = false;
      }
    }
    
    function stackCardsInitEvent(element) {
      element.scrollingFn = stackCardsScrolling.bind(element);
      window.addEventListener('scroll', element.scrollingFn);
    }

    function stackCardsScrolling() {
      if(this.scrolling) return;
      this.scrolling = true;
      window.requestAnimationFrame(animateStackCards.bind(this));
    }

    function setStackCards(element) {
      // Get CSS custom property for gap
      element.marginY = getComputedStyle(element.element).getPropertyValue('--stack-cards-gap');
      getIntegerFromProperty(element);
      element.elementHeight = element.element.offsetHeight;

      // Store card properties
      var cardStyle = getComputedStyle(element.items[0]);
      element.cardTop = Math.floor(parseFloat(cardStyle.getPropertyValue('top')));
      element.cardHeight = Math.floor(parseFloat(cardStyle.getPropertyValue('height')));
      element.windowHeight = window.innerHeight;

      // Set initial positioning
      if(isNaN(element.marginY)) {
        element.element.style.paddingBottom = '0px';
      } else {
        element.element.style.paddingBottom = (element.marginY*(element.items.length - 1))+'px';
      }

      for(var i = 0; i < element.items.length; i++) {
        if(isNaN(element.marginY)) {
          element.items[i].style.transform = 'none';
        } else {
          element.items[i].style.transform = 'translateY('+element.marginY*i+'px)';
        }
      }
    }

    function getIntegerFromProperty(element) {
      var node = document.createElement('div');
      node.setAttribute('style', 'opacity:0; visibility: hidden; position: absolute; height:'+element.marginY);
      element.element.appendChild(node);
      element.marginY = parseInt(getComputedStyle(node).getPropertyValue('height'));
      element.element.removeChild(node);
    }

    function animateStackCards() {
      if(isNaN(this.marginY)) {
        this.scrolling = false;
        return; 
      }

      var top = this.element.getBoundingClientRect().top;

      if( this.cardTop - top + this.element.windowHeight - this.elementHeight - this.cardHeight + this.marginY + this.marginY*this.items.length > 0) { 
        this.scrolling = false;
        return;
      }

      for(var i = 0; i < this.items.length; i++) {
        var scrolling = this.cardTop - top - i*(this.cardHeight+this.marginY);
        if(scrolling > 0) {  
          var scaling = i == this.items.length - 1 ? 1 : (this.cardHeight - scrolling*0.05)/this.cardHeight;
          this.items[i].style.transform = 'translateY('+this.marginY*i+'px) scale('+scaling+')';
        } else {
          this.items[i].style.transform = 'translateY('+this.marginY*i+'px)';
        }
      }

      this.scrolling = false;
    }

    // Initialize StackCards
    var stackCards = document.getElementsByClassName('js-stack-cards');
    var intersectionObserverSupported = ('IntersectionObserver' in window && 'IntersectionObserverEntry' in window && 'intersectionRatio' in window.IntersectionObserverEntry.prototype);
    var reducedMotion = hasReducedMotion();
      
    if(stackCards.length > 0 && intersectionObserverSupported && !reducedMotion) { 
      var stackCardsArray = [];
      for(var i = 0; i < stackCards.length; i++) {
        (function(i){
          stackCardsArray.push(new StackCards(stackCards[i]));
        })(i);
      }
      
      // Handle window resize
      var resizingId = false;
      var customEvent = new CustomEvent('resize-stack-cards');
      
      window.addEventListener('resize', function() {
        clearTimeout(resizingId);
        resizingId = setTimeout(doneResizing, 500);
      });

      function doneResizing() {
        for( var i = 0; i < stackCardsArray.length; i++) {
          (function(i){stackCardsArray[i].element.dispatchEvent(customEvent)})(i);
        }
      }
    }
  })();
<?php

// Include all PHP files from specific subfolders inside 'inc'
function include_rewild_files()
{
    $folders = array(
        'Home metabox',
        'Service metabox',
        'About Metabox',
        'Team metabox',
        'Contact metabox',
    );

    foreach ($folders as $folder) {
        $folder_path = get_template_directory() . '/inc/' . $folder . '/';

        if (is_dir($folder_path)) {
            foreach (glob($folder_path . '*.php') as $file) {
                include_once $file;
            }
        }
    }
    add_theme_support('custom-logo');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');

    register_nav_menus(array(
        'primary' => __('Primary Menu', 'smart-calsee'),
        'footer' => __('Footer Menu', 'smart-calsee'),
        'legal' => __('Footer Legal', 'smart-calsee'),
        'social' => __('Footer Social', 'smart-calsee'),
    ));

}
add_action('after_setup_theme', 'include_rewild_files');



//svg support
function allow_svg_uploads($mimes)
{
    $mimes['svg'] = 'image/svg+xml';
    return $mimes;
}
add_filter('upload_mimes', 'allow_svg_uploads');

// body class add
function add_custom_body_class($classes)
{
    $classes[] = 'smart-body-dots'; // 👈 your new class
    return $classes;
}
add_filter('body_class', 'add_custom_body_class');

add_action('admin_enqueue_scripts', function () {
    wp_enqueue_media();
});

// Enqueue styles and scripts (Bootstrap, Google Fonts, theme CSS/JS)
function smart_calsee_enqueue_scripts()
{

    // Bootstrap CSS (CDN)
    wp_enqueue_style('bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css', array(), '5.3.2');
    wp_enqueue_style('smart-custom-css', get_template_directory_uri() . '/assets/css/custom.css', true);
    wp_enqueue_style('smart-home-css', get_template_directory_uri() . '/assets/css/home.css', true);
    wp_enqueue_style('smart-service-css', get_template_directory_uri() . '/assets/css/service.css', true);
    wp_enqueue_style('smart-team-css', get_template_directory_uri() . '/assets/css/team.css', true);
    wp_enqueue_style('smart-about-css', get_template_directory_uri() . '/assets/css/about.css', true);
    wp_enqueue_style('smart-contact-css', get_template_directory_uri() . '/assets/css/contact.css', true);
        wp_enqueue_style('smart-details-service-css', get_template_directory_uri() . '/assets/css/service-details.css', true);
                wp_enqueue_style('smart-blog-css', get_template_directory_uri() . '/assets/css/single-blog-latest.css', true);


    // wp_enqueue_style( 'smart-calsee-style', get_template_directory_uri() . '/assets/css/custom.css', array(), wp_get_theme()->get( 'Version' ) );
    wp_enqueue_script('bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js', array(), '5.3.2', true);

    wp_enqueue_script('three-js', 'https://cdn.jsdelivr.net/npm/three@0.148.0/build/three.min.js', array(),'0.148.0', true );

    // GSAP Core (single source of truth for all animations)
    wp_enqueue_script('gsap-js',  get_template_directory_uri() . '/assets/js/gsap.min.js', array(), null, true);

    wp_enqueue_style( 'bootstrap-icons', 'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css' );

    // ScrollTrigger + ScrollSmoother (use same GSAP instance)
    wp_enqueue_script('scrolltrigger-js', get_template_directory_uri() . '/assets/js/ScrollTrigger.min.js', array('gsap-js'), null, true);
    wp_enqueue_script('scrollsmoother-js', get_template_directory_uri() . '/assets/js/ScrollSmoother.min.js', array('gsap-js', 'scrolltrigger-js'), null, true);

    // Simplex Noise
    wp_enqueue_script( 'simplex-noise-js', 'https://cdnjs.cloudflare.com/ajax/libs/simplex-noise/2.4.0/simplex-noise.min.js',  array(),  '2.4.0', true );
    // Theme JS
    wp_enqueue_script('smart-calsee-about-js', get_template_directory_uri() . '/assets/js/about.js', array('jquery', 'three-js'), wp_get_theme()->get('Version'), true);
    wp_enqueue_script(
        'smart-calsee-js',
        get_template_directory_uri() . '/assets/js/custom-script.js',
        array('jquery', 'gsap-js', 'scrolltrigger-js', 'scrollsmoother-js', 'simplex-noise-js'),
        wp_get_theme()->get('Version'),
        true
    );
    wp_localize_script( 'smart-calsee-js', 'ThemeData', [
  'assetsUrl' => get_template_directory_uri() . '/assets/image/'  // trailing slash
] );
}   
add_action('wp_enqueue_scripts', 'smart_calsee_enqueue_scripts');

function smart_get_country_slug($term) {
  if (is_numeric($term)) {
    $term = get_term($term, 'service_category');
  }
  if (!$term || is_wp_error($term)) {
    return '';
  }
  
  $slug = $term->slug;
  $name_lower = strtolower($term->name);
  
  // Map common country names to SEO-friendly slugs
  $country_map = array(
    'australia' => 'au',
    'usa' => 'usa',
    'united states' => 'usa',
    'united states of america' => 'usa',
    'us' => 'usa',
  );
  
  if (isset($country_map[$name_lower])) {
    return $country_map[$name_lower];
  }
  
  // If slug is already short (2-3 chars), use it
  if (strlen($slug) <= 3) {
    return $slug;
  }
  
  // Otherwise use slugified version
  return $slug;
}
/**
 * Enqueue About Timeline assets + pass data to JS
 */
function smart_about_timeline_assets() {

    // Only on About Us page (by slug OR template)
    if ( ! is_page( 'about-us' ) && ! is_page_template( 'template/about-template.php' ) ) {
        return;
    }

    $post_id = get_queried_object_id();
    if ( ! $post_id ) return;

    $items = get_post_meta( $post_id, '_about_timeline_items', true );
    if ( ! is_array( $items ) || empty( $items ) ) {
        // If no timeline items, still enqueue script but with empty data
        $items = array();
    }

    $timeline_data = array();
    foreach ( $items as $item ) {
        $year = isset( $item['year'] ) ? trim( $item['year'] ) : '';
        $headline = isset( $item['headline'] ) ? trim( $item['headline'] ) : '';
        $description = isset( $item['description'] ) ? trim( $item['description'] ) : '';
        
        // Skip empty items
        if ( empty( $year ) && empty( $headline ) && empty( $description ) ) {
            continue;
        }
        
        $timeline_data[] = array(
            'year'        => ! empty( $year ) ? (int) $year : 0,
            'title'       => $headline,
            'description' => $description,
            'logo'        => '', // optional, you can add another meta later
        );
    }

    // Use the already-enqueued GSAP + ScrollTrigger from the theme to avoid duplicates
    wp_enqueue_script(
        'about-timeline',
        get_template_directory_uri() . '/assets/js/timeline.js',
        array( 'gsap-js', 'scrolltrigger-js' ),
        '1.0.2', // Version updated
        true
    );

    // Pass PHP data → JS
    wp_localize_script(
        'about-timeline',
        'AboutTimelineData',
        array(
            'items' => $timeline_data,
        )
    );
}
add_action( 'wp_enqueue_scripts', 'smart_about_timeline_assets' );

// Make sure classic editor APIs (wp.editor / wp.oldEditor) are loaded
add_action( 'admin_enqueue_scripts', 'sc_enqueue_editor_assets' );
function sc_enqueue_editor_assets( $hook ) {
    if ( $hook !== 'post.php' && $hook !== 'post-new.php' ) {
        return;
    }

    $screen = get_current_screen();
    if ( ! $screen || $screen->post_type !== 'services' ) {
        return;
    }

    wp_enqueue_editor(); // IMPORTANT for wp.editor / wp.oldEditor JS
        wp_enqueue_media();

}

add_action('admin_footer', function(){
?>
<script>
jQuery(document).ready(function($){
    $('#post').on('submit', function(){
        if ( typeof tinyMCE !== 'undefined' ) {
            tinyMCE.triggerSave();
        }
    });
});
</script>
<?php
});

/**
 * Country Management System
 * Handles country selection (USA/Australia) for content switching
 */

// Valid countries
function smart_get_valid_countries() {
    return array(
        'usa' => array(
            'code' => 'usa',
            'name' => 'USA',
            'slug' => 'usa',
        ),
        'au' => array(
            'code' => 'au',
            'name' => 'Australia',
            'slug' => 'au',
        ),
    );
}

// Get current selected country (from cookie, default to 'usa')
function smart_get_current_country() {
    // Check cookie first
    if ( isset( $_COOKIE['smart_selected_country'] ) ) {
        $country = sanitize_text_field( $_COOKIE['smart_selected_country'] );
        $valid_countries = smart_get_valid_countries();
        if ( isset( $valid_countries[ $country ] ) ) {
            return $country;
        }
    }
    
    // Default to USA
    return 'usa';
}

// Get country-specific meta value
// Usage: smart_get_country_meta( $post_id, '_hero_title', 'usa' )
function smart_get_country_meta( $post_id, $meta_key, $country = null ) {
    if ( ! $country ) {
        $country = smart_get_current_country();
    }
    
    // Try country-specific meta first (e.g., _hero_title_usa, _hero_title_au)
    $country_meta_key = $meta_key . '_' . $country;
    $value = get_post_meta( $post_id, $country_meta_key, true );
    
    // If no country-specific value, fallback to default meta
    if ( empty( $value ) ) {
        $value = get_post_meta( $post_id, $meta_key, true );
    }
    
    return $value;
}

// AJAX handler for country switching
add_action( 'wp_ajax_smart_switch_country', 'smart_ajax_switch_country' );
add_action( 'wp_ajax_nopriv_smart_switch_country', 'smart_ajax_switch_country' );
function smart_ajax_switch_country() {
    check_ajax_referer( 'smart_country_nonce', 'nonce' );
    
    $country = isset( $_POST['country'] ) ? sanitize_text_field( $_POST['country'] ) : '';
    $valid_countries = smart_get_valid_countries();
    
    if ( ! isset( $valid_countries[ $country ] ) ) {
        wp_send_json_error( array( 'message' => 'Invalid country' ) );
    }
    
    // Set cookie (30 days expiry)
    setcookie( 'smart_selected_country', $country, time() + ( 30 * DAY_IN_SECONDS ), '/' );
    $_COOKIE['smart_selected_country'] = $country;
    
    wp_send_json_success( array(
        'country' => $country,
        'name' => $valid_countries[ $country ]['name'],
        'redirect' => isset( $_POST['redirect'] ) ? esc_url_raw( $_POST['redirect'] ) : home_url( '/' ),
    ) );
}

// Enqueue AJAX script for country switching
add_action( 'wp_enqueue_scripts', 'smart_enqueue_country_switcher' );
function smart_enqueue_country_switcher() {
    wp_localize_script( 'smart-calsee-js', 'SmartCountry', array(
        'ajaxUrl' => admin_url( 'admin-ajax.php' ),
        'nonce' => wp_create_nonce( 'smart_country_nonce' ),
        'currentCountry' => smart_get_current_country(),
    ) );
}


<?php

/**
 * Add section-wise metaboxes for Services
 */
add_action('add_meta_boxes', 'sc_service_add_metaboxes');
function sc_service_add_metaboxes()
{

    $post_type = 'services'; // change if your CPT slug is different

    // Hero Section
    add_meta_box(
        'sc_hero_section',
        'Hero Section',
        'sc_hero_section_html',
        $post_type,
        'normal',
        'high'
    );

    // About Section
    add_meta_box(
        'sc_about_section',
        'About Service Section',
        'sc_about_section_html',
        $post_type,
        'normal',
        'high'
    );

    // Bookkeeping Solutions Section (Accordion)
    add_meta_box(
        'sc_solutions_section',
        'Solutions Section (Accordion)',
        'sc_solutions_section_html',
        $post_type,
        'normal',
        'high'
    );

    add_meta_box(
        'sc_industry_section',
        'Industry Expertise Section',
        'sc_industry_section_html',
        'services',   // your CPT
        'normal',
        'high'
    );

    // Why Outsource Section
    add_meta_box(
        'sc_outsource_section',
        'Why Outsource Section',
        'sc_outsource_section_html',
        $post_type,
        'normal',
        'high'
    );

    // FAQs Section
    add_meta_box(
        'sc_faq_section',
        'FAQs Section',
        'sc_faq_section_html',
        $post_type,
        'normal',
        'high'
    );
}

/**
 * Hero Section Metabox
 */
function sc_hero_section_html($post)
{
    wp_nonce_field('sc_hero_nonce_action', 'sc_hero_nonce');
    
    $countries = array( 'usa' => 'USA', 'au' => 'Australia' );
    ?>
    <style>
    .country-tabs { display: flex; gap: 10px; margin-bottom: 20px; border-bottom: 2px solid #ddd; }
    .country-tab { padding: 10px 20px; cursor: pointer; background: #f5f5f5; border: none; border-bottom: 3px solid transparent; }
    .country-tab.active { background: #fff; border-bottom-color: #0073aa; font-weight: bold; }
    .country-content { display: none; }
    .country-content.active { display: block; }
    </style>
    
    <div class="country-tabs">
        <?php foreach ( $countries as $code => $name ) : ?>
            <button type="button" class="country-tab <?php echo $code === 'usa' ? 'active' : ''; ?>" data-country="<?php echo esc_attr( $code ); ?>">
                <?php echo esc_html( $name ); ?>
            </button>
        <?php endforeach; ?>
    </div>

    <?php foreach ( $countries as $code => $name ) : 
        $hero_title = get_post_meta($post->ID, '_sc_hero_title_' . $code, true);
        $hero_desc  = get_post_meta($post->ID, '_sc_hero_desc_' . $code, true);
        
        if ( empty( $hero_title ) ) $hero_title = get_post_meta($post->ID, '_sc_hero_title', true);
        if ( empty( $hero_desc ) ) $hero_desc = get_post_meta($post->ID, '_sc_hero_desc', true);
    ?>
    <div class="country-content <?php echo $code === 'usa' ? 'active' : ''; ?>" data-country="<?php echo esc_attr( $code ); ?>">
        <h3 style="margin-top: 0;"><?php echo esc_html( $name ); ?> Hero Section</h3>
        <p>
            <label><strong>Hero Heading</strong></label><br>
            <input type="text" name="sc_hero_title_<?php echo esc_attr( $code ); ?>" style="width:100%;"
                value="<?php echo esc_attr($hero_title); ?>">
        </p>

        <p>
            <label><strong>Hero Description</strong></label><br>
            <?php
            $editor_id = 'sc_hero_desc_editor_' . $code;
            $hero_settings = [
                'textarea_name' => 'sc_hero_desc_' . $code,
                'textarea_rows' => 5,
                'media_buttons' => true,
                'tinymce'       => true,
                'quicktags'     => true,
            ];
            wp_editor($hero_desc, $editor_id, $hero_settings);
            ?>
        </p>
    </div>
    <?php endforeach; ?>
    
    <script>
    jQuery(document).ready(function($) {
        $('.country-tab').on('click', function() {
            var country = $(this).data('country');
            $('.country-tab').removeClass('active');
            $(this).addClass('active');
            $('.country-content').removeClass('active');
            $('.country-content[data-country="' + country + '"]').addClass('active');
        });
    });
    </script>
<?php
}

/**
 * About Section Metabox
 */
function sc_about_section_html($post)
{
    wp_nonce_field('sc_about_nonce_action', 'sc_about_nonce');
    
    $countries = array( 'usa' => 'USA', 'au' => 'Australia' );
    ?>
    <style>
    .country-tabs { display: flex; gap: 10px; margin-bottom: 20px; border-bottom: 2px solid #ddd; }
    .country-tab { padding: 10px 20px; cursor: pointer; background: #f5f5f5; border: none; border-bottom: 3px solid transparent; }
    .country-tab.active { background: #fff; border-bottom-color: #0073aa; font-weight: bold; }
    .country-content { display: none; }
    .country-content.active { display: block; }
    </style>
    
    <div class="country-tabs">
        <?php foreach ( $countries as $code => $name ) : ?>
            <button type="button" class="country-tab <?php echo $code === 'usa' ? 'active' : ''; ?>" data-country="<?php echo esc_attr( $code ); ?>">
                <?php echo esc_html( $name ); ?>
            </button>
        <?php endforeach; ?>
    </div>

    <?php foreach ( $countries as $code => $name ) : 
        $about_title = get_post_meta($post->ID, '_sc_about_title_' . $code, true);
        $about_sub   = get_post_meta($post->ID, '_sc_about_sub_' . $code, true);
        $about_text  = get_post_meta($post->ID, '_sc_about_text_' . $code, true);
        
        if ( empty( $about_title ) ) $about_title = get_post_meta($post->ID, '_sc_about_title', true);
        if ( empty( $about_sub ) ) $about_sub = get_post_meta($post->ID, '_sc_about_sub', true);
        if ( empty( $about_text ) ) $about_text = get_post_meta($post->ID, '_sc_about_text', true);
    ?>
    <div class="country-content <?php echo $code === 'usa' ? 'active' : ''; ?>" data-country="<?php echo esc_attr( $code ); ?>">
        <h3 style="margin-top: 0;"><?php echo esc_html( $name ); ?> About Section</h3>
        <p>
            <label><strong>Section Title</strong></label><br>
            <input type="text" name="sc_about_title_<?php echo esc_attr( $code ); ?>" style="width:100%;"
                value="<?php echo esc_attr($about_title); ?>">
        </p>
        <p>
            <label><strong>Short Subtitle</strong></label><br>
            <input type="text" name="sc_about_sub_<?php echo esc_attr( $code ); ?>" style="width:100%;"
                value="<?php echo esc_attr($about_sub); ?>">
        </p>
        <p>
            <label><strong>Description</strong></label><br>
            <?php
            $editor_id = 'sc_about_text_editor_' . $code;
            $about_settings = [
                'textarea_name' => 'sc_about_text_' . $code,
                'textarea_rows' => 8,
                'media_buttons' => true,
                'tinymce'       => true,
                'quicktags'     => true,
            ];
            wp_editor($about_text, $editor_id, $about_settings);
            ?>
        </p>
    </div>
    <?php endforeach; ?>
    
    <script>
    jQuery(document).ready(function($) {
        $('.country-tab').on('click', function() {
            var country = $(this).data('country');
            $('.country-tab').removeClass('active');
            $(this).addClass('active');
            $('.country-content').removeClass('active');
            $('.country-content[data-country="' + country + '"]').addClass('active');
        });
    });
    </script>
<?php
}

/**
 * Solutions (Accordion) Metabox
 */
function sc_solutions_section_html($post)
{
    wp_nonce_field('sc_solutions_nonce_action', 'sc_solutions_nonce');
    
    $countries = array( 'usa' => 'USA', 'au' => 'Australia' );
    ?>
    <style>
    .country-tabs { display: flex; gap: 10px; margin-bottom: 20px; border-bottom: 2px solid #ddd; }
    .country-tab { padding: 10px 20px; cursor: pointer; background: #f5f5f5; border: none; border-bottom: 3px solid transparent; }
    .country-tab.active { background: #fff; border-bottom-color: #0073aa; font-weight: bold; }
    .country-content { display: none; }
    .country-content.active { display: block; }
    </style>
    
    <div class="country-tabs">
        <?php foreach ( $countries as $code => $name ) : ?>
            <button type="button" class="country-tab <?php echo $code === 'usa' ? 'active' : ''; ?>" data-country="<?php echo esc_attr( $code ); ?>">
                <?php echo esc_html( $name ); ?>
            </button>
        <?php endforeach; ?>
    </div>

    <?php foreach ( $countries as $code => $name ) : 
        $section_title = get_post_meta($post->ID, '_sc_solutions_title_' . $code, true);
        $section_intro = get_post_meta($post->ID, '_sc_solutions_intro_' . $code, true);
        $solutions     = get_post_meta($post->ID, '_sc_solutions_' . $code, true);
        
        if ( empty( $section_title ) ) $section_title = get_post_meta($post->ID, '_sc_solutions_title', true);
        if ( empty( $section_intro ) ) $section_intro = get_post_meta($post->ID, '_sc_solutions_intro', true);
        if ( empty( $solutions ) ) $solutions = get_post_meta($post->ID, '_sc_solutions', true);

        if (! is_array($solutions)) {
            $solutions = [];
        }
    ?>
    <div class="country-content <?php echo $code === 'usa' ? 'active' : ''; ?>" data-country="<?php echo esc_attr( $code ); ?>">
        <h3 style="margin-top: 0;"><?php echo esc_html( $name ); ?> Solutions Section</h3>
        <p>
            <label><strong>Section Title</strong></label><br>
            <input type="text" name="sc_solutions_title_<?php echo esc_attr( $code ); ?>" style="width:100%;"
                value="<?php echo esc_attr($section_title); ?>">
        </p>
        <p>
            <label><strong>Intro Text (optional)</strong></label><br>
            <?php
            $editor_id = 'sc_solutions_intro_editor_' . $code;
            $solutions_intro_settings = [
                'textarea_name' => 'sc_solutions_intro_' . $code,
                'textarea_rows' => 5,
                'media_buttons' => true,
                'tinymce'       => true,
                'quicktags'     => true,
            ];
            wp_editor($section_intro, $editor_id, $solutions_intro_settings);
            ?>
        </p>

        <hr>
        <h4>Accordion Items</h4>

        <div id="sc-solutions-wrapper-<?php echo esc_attr( $code ); ?>">
            <?php if (empty($solutions)) : ?>
                <?php $solutions[] = ['title' => '', 'content' => '']; ?>
            <?php endif; ?>

            <?php foreach ($solutions as $index => $item) : ?>
                <div class="sc-solution-item"
                    data-index="<?php echo esc_attr($index); ?>"
                    style="border:1px solid #ddd;margin-bottom:10px;padding:10px;">
                    <p>
                        <label><strong>Item Title</strong></label><br>
                        <input type="text" style="width:100%;"
                            name="sc_solutions_<?php echo esc_attr( $code ); ?>[<?php echo esc_attr($index); ?>][title]"
                            value="<?php echo esc_attr($item['title'] ?? ''); ?>">
                    </p>
                    <p>
                        <label><strong>Item Content</strong></label><br>
                        <?php
                        $content          = $item['content'] ?? '';
                        $editor_id        = 'sc_solutions_content_' . $code . '_' . $index;
                        $editor_settings  = [
                            'textarea_name' => "sc_solutions_{$code}[{$index}][content]",
                            'textarea_rows' => 5,
                            'media_buttons' => true,
                            'tinymce'       => true,
                            'quicktags'     => true,
                        ];
                        wp_editor($content, $editor_id, $editor_settings);
                        ?>
                    </p>
                    <button type="button" class="button sc-remove-solution">Remove</button>
                </div>
            <?php endforeach; ?>
        </div>

        <p>
            <button type="button" class="button button-primary sc-add-solution" data-country="<?php echo esc_attr( $code ); ?>">+ Add Item</button>
        </p>
    </div>
    <?php endforeach; ?>

    <script>
        jQuery(document).ready(function($) {
            // Country tab switching
            $('.country-tab').on('click', function() {
                var country = $(this).data('country');
                $('.country-tab').removeClass('active');
                $(this).addClass('active');
                $('.country-content').removeClass('active');
                $('.country-content[data-country="' + country + '"]').addClass('active');
            });

            var solutionIndices = {};

            function getWpEditorModule() {
                if (typeof wp !== 'undefined') {
                    if (wp.editor && typeof wp.editor.initialize === 'function') {
                        return wp.editor;
                    }
                    if (wp.oldEditor && typeof wp.oldEditor.initialize === 'function') {
                        return wp.oldEditor;
                    }
                }
                return null;
            }

            function initWpEditorForSolution(country, index) {
                const editorId = 'sc_solutions_content_' + country + '_' + index;
                const editorModule = getWpEditorModule();

                if (editorModule) {
                    editorModule.initialize(editorId, {
                        tinymce: {
                            wpautop: true,
                            toolbar1: 'bold,italic,bullist,numlist,link,unlink,undo,redo',
                        },
                        quicktags: true,
                        mediaButtons: true
                    });
                }
            }

            $(document).on('click', '.sc-add-solution', function() {
                var country = $(this).data('country');
                if (!solutionIndices[country]) {
                    solutionIndices[country] = $('#sc-solutions-wrapper-' + country + ' .sc-solution-item').length;
                }
                const indexAttr = solutionIndices[country];
                const editorId = 'sc_solutions_content_' + country + '_' + indexAttr;

                let html = '<div class="sc-solution-item" data-index="' + indexAttr + '" style="border:1px solid #ddd;margin-bottom:10px;padding:10px;">' +
                    '<p><label><strong>Item Title</strong></label><br>' +
                    '<input type="text" style="width:100%;" name="sc_solutions_' + country + '[' + indexAttr + '][title]" value=""></p>' +
                    '<p><label><strong>Item Content</strong></label><br>' +
                    '<textarea id="' + editorId + '" style="width:100%;height:80px;" name="sc_solutions_' + country + '[' + indexAttr + '][content]"></textarea></p>' +
                    '<button type="button" class="button sc-remove-solution">Remove</button>' +
                    '</div>';

                $('#sc-solutions-wrapper-' + country).append(html);

                // Initialize wp_editor on the new textarea
                initWpEditorForSolution(country, indexAttr);

                solutionIndices[country]++;
            });

            $(document).on('click', '.sc-remove-solution', function() {
                const $item = $(this).closest('.sc-solution-item');
                const index = $item.data('index');
                const $countryContent = $item.closest('.country-content');
                const country = $countryContent.data('country');
                const editorId = 'sc_solutions_content_' + country + '_' + index;
                const editorModule = getWpEditorModule();

                if (editorModule && typeof editorModule.remove === 'function') {
                    editorModule.remove(editorId);
                }

                $item.remove();
            });
        });
    </script>
<?php
}

// 
function sc_industry_section_html( $post ) {
    wp_nonce_field( 'sc_industry_nonce_action', 'sc_industry_nonce' );
    
    $countries = array( 'usa' => 'USA', 'au' => 'Australia' );
    ?>
    <style>
    .country-tabs { display: flex; gap: 10px; margin-bottom: 20px; border-bottom: 2px solid #ddd; }
    .country-tab { padding: 10px 20px; cursor: pointer; background: #f5f5f5; border: none; border-bottom: 3px solid transparent; }
    .country-tab.active { background: #fff; border-bottom-color: #0073aa; font-weight: bold; }
    .country-content { display: none; }
    .country-content.active { display: block; }
    </style>
    
    <div class="country-tabs">
        <?php foreach ( $countries as $code => $name ) : ?>
            <button type="button" class="country-tab <?php echo $code === 'usa' ? 'active' : ''; ?>" data-country="<?php echo esc_attr( $code ); ?>">
                <?php echo esc_html( $name ); ?>
            </button>
        <?php endforeach; ?>
    </div>

    <?php foreach ( $countries as $code => $name ) : 
        $section_title = get_post_meta( $post->ID, '_sc_industry_title_' . $code, true );
        $items         = get_post_meta( $post->ID, '_sc_industry_items_' . $code, true );
        
        if ( empty( $section_title ) ) $section_title = get_post_meta( $post->ID, '_sc_industry_title', true );
        if ( empty( $items ) ) $items = get_post_meta( $post->ID, '_sc_industry_items', true );

        if ( ! is_array( $items ) ) {
            $items = [];
        }
    ?>
    <div class="country-content <?php echo $code === 'usa' ? 'active' : ''; ?>" data-country="<?php echo esc_attr( $code ); ?>">
        <h3 style="margin-top: 0;"><?php echo esc_html( $name ); ?> Industry Section</h3>
        <p>
            <label><strong>Section Title</strong></label><br>
            <input type="text" name="sc_industry_title_<?php echo esc_attr( $code ); ?>" style="width:100%;"
                   value="<?php echo esc_attr( $section_title ); ?>">
        </p>

        <hr>
        <h4>Industry Cards</h4>

        <div id="sc-industry-wrapper-<?php echo esc_attr( $code ); ?>">
            <?php if ( empty( $items ) ) : ?>
                <?php $items[] = [ 'icon' => '', 'title' => '', 'desc' => '' ]; ?>
            <?php endif; ?>

            <?php foreach ( $items as $index => $item ) : ?>
                <div class="sc-industry-item" style="border:1px solid #ddd;margin-bottom:10px;padding:10px;">

                    <p>
                        <label><strong>Icon</strong></label><br>
                        <div class="industry-image-wrapper">
                            <?php
                            $icon_url = isset( $item['icon'] ) ? $item['icon'] : '';
                            $has_icon = ! empty( $icon_url );
                            ?>
                            <img src="<?php echo esc_url( $icon_url ); ?>"
                                 class="industry-preview"
                                 style="max-width:60px; max-height:60px; <?php echo $has_icon ? '' : 'display:none;'; ?> margin-bottom:10px; border:1px solid #ccc; border-radius:4px; padding:3px;">

                            <input type="hidden"
                                   name="sc_industry_items_<?php echo esc_attr( $code ); ?>[<?php echo esc_attr( $index ); ?>][icon]"
                                   class="industry-input"
                                   value="<?php echo esc_attr( $icon_url ); ?>">

                            <button type="button" class="button industry-upload-btn">Upload Icon</button>
                            <button type="button" class="button industry-remove-btn" style="margin-left:5px; <?php echo $has_icon ? '' : 'display:none;'; ?>">Remove</button>
                        </div>
                    </p>

                    <p>
                        <label><strong>Industry Title</strong></label><br>
                        <input type="text" style="width:100%;"
                               name="sc_industry_items_<?php echo esc_attr( $code ); ?>[<?php echo esc_attr( $index ); ?>][title]"
                               value="<?php echo esc_attr( $item['title'] ?? '' ); ?>">
                    </p>

                    <p>
                        <label><strong>Short Description</strong></label><br>
                        <textarea style="width:100%;height:60px;"
                                  name="sc_industry_items_<?php echo esc_attr( $code ); ?>[<?php echo esc_attr( $index ); ?>][desc]"><?php
                            echo esc_textarea( $item['desc'] ?? '' );
                        ?></textarea>
                    </p>

                    <button type="button" class="button sc-remove-industry">Remove</button>
                </div>
            <?php endforeach; ?>
        </div>

        <p>
            <button type="button" class="button button-primary sc-add-industry" data-country="<?php echo esc_attr( $code ); ?>">+ Add Industry</button>
        </p>
    </div>
    <?php endforeach; ?>

    <script>
    jQuery(document).ready(function ($) {
        // Country tab switching
        $('.country-tab').on('click', function() {
            var country = $(this).data('country');
            $('.country-tab').removeClass('active');
            $(this).addClass('active');
            $('.country-content').removeClass('active');
            $('.country-content[data-country="' + country + '"]').addClass('active');
        });

        var industryIndices = {};

        // Add new industry card
        $(document).on('click', '.sc-add-industry', function () {
            var country = $(this).data('country');
            if (!industryIndices[country]) {
                industryIndices[country] = $('#sc-industry-wrapper-' + country + ' .sc-industry-item').length;
            }
            var indexAttr = industryIndices[country];
            
            let html = '<div class="sc-industry-item" style="border:1px solid #ddd;margin-bottom:10px;padding:10px;">' +
                '<p><label><strong>Icon</strong></label><br>' +
                '<div class="industry-image-wrapper">' +
                '<img src="" class="industry-preview" style="max-width:60px; max-height:60px; display:none; margin-bottom:10px; border:1px solid #ccc; border-radius:4px; padding:3px;">' +
                '<input type="hidden" name="sc_industry_items_' + country + '[' + indexAttr + '][icon]" class="industry-input" value="">' +
                '<button type="button" class="button industry-upload-btn">Upload Icon</button>' +
                '<button type="button" class="button industry-remove-btn" style="margin-left:5px; display:none;">Remove</button>' +
                '</div></p>' +
                '<p><label><strong>Industry Title</strong></label><br>' +
                '<input type="text" style="width:100%;" name="sc_industry_items_' + country + '[' + indexAttr + '][title]" value=""></p>' +
                '<p><label><strong>Short Description</strong></label><br>' +
                '<textarea style="width:100%;height:60px;" name="sc_industry_items_' + country + '[' + indexAttr + '][desc]"></textarea></p>' +
                '<button type="button" class="button sc-remove-industry">Remove</button>' +
                '</div>';

            $('#sc-industry-wrapper-' + country).append(html);
            industryIndices[country]++;
        });

        // Remove card
        $(document).on('click', '.sc-remove-industry', function () {
            $(this).closest('.sc-industry-item').remove();
        });

        // WordPress Media Uploader: open
        $(document).on('click', '.industry-upload-btn', function (e) {
            e.preventDefault();

            const button    = $(this);
            const wrapper   = button.closest('.industry-image-wrapper');
            const inputFld  = wrapper.find('.industry-input');
            const preview   = wrapper.find('.industry-preview');
            const removeBtn = wrapper.find('.industry-remove-btn');

            const frame = wp.media({
                title: 'Select Icon',
                button: { text: 'Use this icon' },
                multiple: false
            });

            frame.on('select', function () {
                const attachment = frame.state().get('selection').first().toJSON();
                inputFld.val(attachment.url);
                preview.attr('src', attachment.url).show();
                removeBtn.show();
            });

            frame.open();
        });

        // Remove icon
        $(document).on('click', '.industry-remove-btn', function (e) {
            e.preventDefault();

            const wrapper = $(this).closest('.industry-image-wrapper');
            wrapper.find('.industry-input').val('');
            wrapper.find('.industry-preview').attr('src', '').hide();
            $(this).hide();
        });

    });
    </script>
    <?php
}

/**
 * Why Outsource Section Metabox
 */
function sc_outsource_section_html($post)
{
    wp_nonce_field('sc_out_nonce_action', 'sc_out_nonce');
    
    $countries = array( 'usa' => 'USA', 'au' => 'Australia' );
    ?>
    <style>
    .country-tabs { display: flex; gap: 10px; margin-bottom: 20px; border-bottom: 2px solid #ddd; }
    .country-tab { padding: 10px 20px; cursor: pointer; background: #f5f5f5; border: none; border-bottom: 3px solid transparent; }
    .country-tab.active { background: #fff; border-bottom-color: #0073aa; font-weight: bold; }
    .country-content { display: none; }
    .country-content.active { display: block; }
    </style>
    
    <div class="country-tabs">
        <?php foreach ( $countries as $code => $name ) : ?>
            <button type="button" class="country-tab <?php echo $code === 'usa' ? 'active' : ''; ?>" data-country="<?php echo esc_attr( $code ); ?>">
                <?php echo esc_html( $name ); ?>
            </button>
        <?php endforeach; ?>
    </div>

    <?php foreach ( $countries as $code => $name ) : 
        $out_title = get_post_meta($post->ID, '_sc_out_title_' . $code, true);
        $out_left  = get_post_meta($post->ID, '_sc_out_left_' . $code, true);
        $out_right = get_post_meta($post->ID, '_sc_out_right_' . $code, true);
        
        if ( empty( $out_title ) ) $out_title = get_post_meta($post->ID, '_sc_out_title', true);
        if ( empty( $out_left ) ) $out_left = get_post_meta($post->ID, '_sc_out_left', true);
        if ( empty( $out_right ) ) $out_right = get_post_meta($post->ID, '_sc_out_right', true);
    ?>
    <div class="country-content <?php echo $code === 'usa' ? 'active' : ''; ?>" data-country="<?php echo esc_attr( $code ); ?>">
        <h3 style="margin-top: 0;"><?php echo esc_html( $name ); ?> Why Outsource Section</h3>
        <p>
            <label><strong>Section Title</strong></label><br>
            <input type="text" name="sc_out_title_<?php echo esc_attr( $code ); ?>" style="width:100%;"
                value="<?php echo esc_attr($out_title); ?>">
        </p>
        <p>
            <label><strong>Left Column Points</strong></label><br>
            <?php
            $editor_id = 'sc_out_left_editor_' . $code;
            $out_left_settings = [
                'textarea_name' => 'sc_out_left_' . $code,
                'textarea_rows' => 8,
                'media_buttons' => true,
                'tinymce'       => true,
                'quicktags'     => true,
            ];
            wp_editor($out_left, $editor_id, $out_left_settings);
            ?>
            <small>One bullet per line (you can style as bullets on frontend).</small>
        </p>
        <p>
            <label><strong>Right Column Points</strong></label><br>
            <?php
            $editor_id = 'sc_out_right_editor_' . $code;
            $out_right_settings = [
                'textarea_name' => 'sc_out_right_' . $code,
                'textarea_rows' => 8,
                'media_buttons' => true,
                'tinymce'       => true,
                'quicktags'     => true,
            ];
            wp_editor($out_right, $editor_id, $out_right_settings);
            ?>
            <small>One bullet per line (you can style as bullets on frontend).</small>
        </p>
    </div>
    <?php endforeach; ?>
    
    <script>
    jQuery(document).ready(function($) {
        $('.country-tab').on('click', function() {
            var country = $(this).data('country');
            $('.country-tab').removeClass('active');
            $(this).addClass('active');
            $('.country-content').removeClass('active');
            $('.country-content[data-country="' + country + '"]').addClass('active');
        });
    });
    </script>
<?php
}

/**
 * FAQ Section Metabox
 */
function sc_faq_section_html($post)
{
    wp_nonce_field('sc_faq_nonce_action', 'sc_faq_nonce');
    
    $countries = array( 'usa' => 'USA', 'au' => 'Australia' );
    ?>
    <style>
    .country-tabs { display: flex; gap: 10px; margin-bottom: 20px; border-bottom: 2px solid #ddd; }
    .country-tab { padding: 10px 20px; cursor: pointer; background: #f5f5f5; border: none; border-bottom: 3px solid transparent; }
    .country-tab.active { background: #fff; border-bottom-color: #0073aa; font-weight: bold; }
    .country-content { display: none; }
    .country-content.active { display: block; }
    </style>
    
    <div class="country-tabs">
        <?php foreach ( $countries as $code => $name ) : ?>
            <button type="button" class="country-tab <?php echo $code === 'usa' ? 'active' : ''; ?>" data-country="<?php echo esc_attr( $code ); ?>">
                <?php echo esc_html( $name ); ?>
            </button>
        <?php endforeach; ?>
    </div>

    <?php foreach ( $countries as $code => $name ) : 
        $faq_title = get_post_meta($post->ID, '_sc_faq_title_' . $code, true);
        $faqs      = get_post_meta($post->ID, '_sc_faqs_' . $code, true);
        
        if ( empty( $faq_title ) ) $faq_title = get_post_meta($post->ID, '_sc_faq_title', true);
        if ( empty( $faqs ) ) $faqs = get_post_meta($post->ID, '_sc_faqs', true);

        if (! is_array($faqs)) {
            $faqs = [];
        }
    ?>
    <div class="country-content <?php echo $code === 'usa' ? 'active' : ''; ?>" data-country="<?php echo esc_attr( $code ); ?>">
        <h3 style="margin-top: 0;"><?php echo esc_html( $name ); ?> FAQ Section</h3>
        <p>
            <label><strong>Section Title</strong></label><br>
            <input type="text" name="sc_faq_title_<?php echo esc_attr( $code ); ?>" style="width:100%;"
                value="<?php echo esc_attr($faq_title); ?>">
        </p>

        <hr>
        <h4>FAQ Items</h4>

        <div id="sc-faq-wrapper-<?php echo esc_attr( $code ); ?>">
            <?php if (empty($faqs)) : ?>
                <?php $faqs[] = ['question' => '', 'answer' => '']; ?>
            <?php endif; ?>

            <?php foreach ($faqs as $index => $faq) : ?>
                <div class="sc-faq-item"
                    data-index="<?php echo esc_attr($index); ?>"
                    style="border:1px solid #ddd;margin-bottom:10px;padding:10px;">
                    <p>
                        <label><strong>Question</strong></label><br>
                        <input type="text" style="width:100%;"
                            name="sc_faqs_<?php echo esc_attr( $code ); ?>[<?php echo esc_attr($index); ?>][question]"
                            value="<?php echo esc_attr($faq['question'] ?? ''); ?>">
                    </p>
                    <p>
                        <label><strong>Answer</strong></label><br>
                        <?php
                        $answer            = $faq['answer'] ?? '';
                        $faq_editor_id     = 'sc_faq_answer_' . $code . '_' . $index;
                        $faq_editor_settings = [
                            'textarea_name' => "sc_faqs_{$code}[{$index}][answer]",
                            'textarea_rows' => 5,
                            'media_buttons' => true,
                            'tinymce'       => true,
                            'quicktags'     => true,
                        ];
                        wp_editor($answer, $faq_editor_id, $faq_editor_settings);
                        ?>
                    </p>
                    <button type="button" class="button sc-remove-faq">Remove</button>
                </div>
            <?php endforeach; ?>
        </div>

        <p>
            <button type="button" class="button button-primary sc-add-faq" data-country="<?php echo esc_attr( $code ); ?>">+ Add FAQ</button>
        </p>
    </div>
    <?php endforeach; ?>

    <script>
        jQuery(document).ready(function($) {
            // Country tab switching
            $('.country-tab').on('click', function() {
                var country = $(this).data('country');
                $('.country-tab').removeClass('active');
                $(this).addClass('active');
                $('.country-content').removeClass('active');
                $('.country-content[data-country="' + country + '"]').addClass('active');
            });

            var faqIndices = {};

            function getWpEditorModule() {
                if (typeof wp !== 'undefined') {
                    if (wp.editor && typeof wp.editor.initialize === 'function') {
                        return wp.editor;
                    }
                    if (wp.oldEditor && typeof wp.oldEditor.initialize === 'function') {
                        return wp.oldEditor;
                    }
                }
                return null;
            }

            function initWpEditorForFaq(country, index) {
                const editorId = 'sc_faq_answer_' + country + '_' + index;
                const editorModule = getWpEditorModule();

                if (editorModule) {
                    editorModule.initialize(editorId, {
                        tinymce: {
                            wpautop: true,
                            toolbar1: 'bold,italic,bullist,numlist,link,unlink,undo,redo',
                        },
                        quicktags: true,
                        mediaButtons: true
                    });
                }
            }

            // Add new FAQ
            $(document).on('click', '.sc-add-faq', function() {
                var country = $(this).data('country');
                if (!faqIndices[country]) {
                    faqIndices[country] = $('#sc-faq-wrapper-' + country + ' .sc-faq-item').length;
                }
                const indexAttr = faqIndices[country];
                const editorId = 'sc_faq_answer_' + country + '_' + indexAttr;

                let html = '<div class="sc-faq-item" data-index="' + indexAttr + '" style="border:1px solid #ddd;margin-bottom:10px;padding:10px;">' +
                    '<p><label><strong>Question</strong></label><br>' +
                    '<input type="text" style="width:100%;" name="sc_faqs_' + country + '[' + indexAttr + '][question]" value=""></p>' +
                    '<p><label><strong>Answer</strong></label><br>' +
                    '<textarea id="' + editorId + '" style="width:100%;height:80px;" name="sc_faqs_' + country + '[' + indexAttr + '][answer]"></textarea></p>' +
                    '<button type="button" class="button sc-remove-faq">Remove</button>' +
                    '</div>';

                $('#sc-faq-wrapper-' + country).append(html);

                // Initialize wp_editor on the new textarea
                initWpEditorForFaq(country, indexAttr);

                faqIndices[country]++;
            });

            // Remove FAQ (and its editor)
            $(document).on('click', '.sc-remove-faq', function() {
                const $item = $(this).closest('.sc-faq-item');
                const index = $item.data('index');
                const $countryContent = $item.closest('.country-content');
                const country = $countryContent.data('country');
                const editorId = 'sc_faq_answer_' + country + '_' + index;
                const editorModule = getWpEditorModule();

                if (editorModule && typeof editorModule.remove === 'function') {
                    editorModule.remove(editorId);
                }

                $item.remove();
            });
        });
    </script>
<?php
}

/**
 * Save all sections
 */
add_action('save_post', 'sc_service_save_all_sections');
function sc_service_save_all_sections($post_id)
{

    // 1. Basic checks
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (! isset($_POST['post_type']) || $_POST['post_type'] !== 'services') {
        return;
    }

    if (! current_user_can('edit_post', $post_id)) {
        return;
    }

    /**
     * Hero Section Save
     */
    if (
        isset($_POST['sc_hero_nonce']) &&
        wp_verify_nonce($_POST['sc_hero_nonce'], 'sc_hero_nonce_action')
    ) {

        // Save country-specific hero values
        $countries = array( 'usa', 'au' );
        foreach ( $countries as $code ) {
            if (isset($_POST['sc_hero_title_' . $code])) {
                update_post_meta(
                    $post_id,
                    '_sc_hero_title_' . $code,
                    sanitize_text_field($_POST['sc_hero_title_' . $code])
                );
            } else {
                delete_post_meta( $post_id, '_sc_hero_title_' . $code );
            }

            if (isset($_POST['sc_hero_desc_' . $code])) {
                update_post_meta(
                    $post_id,
                    '_sc_hero_desc_' . $code,
                    wp_kses_post($_POST['sc_hero_desc_' . $code])
                );
            } else {
                delete_post_meta( $post_id, '_sc_hero_desc_' . $code );
            }
        }
    }

    /**
     * About Section Save
     */
    if (
        isset($_POST['sc_about_nonce']) &&
        wp_verify_nonce($_POST['sc_about_nonce'], 'sc_about_nonce_action')
    ) {

        // Save country-specific about values
        $countries = array( 'usa', 'au' );
        foreach ( $countries as $code ) {
            if (isset($_POST['sc_about_title_' . $code])) {
                update_post_meta(
                    $post_id,
                    '_sc_about_title_' . $code,
                    sanitize_text_field($_POST['sc_about_title_' . $code])
                );
            } else {
                delete_post_meta( $post_id, '_sc_about_title_' . $code );
            }

            if (isset($_POST['sc_about_sub_' . $code])) {
                update_post_meta(
                    $post_id,
                    '_sc_about_sub_' . $code,
                    sanitize_text_field($_POST['sc_about_sub_' . $code])
                );
            } else {
                delete_post_meta( $post_id, '_sc_about_sub_' . $code );
            }

            if (isset($_POST['sc_about_text_' . $code])) {
                update_post_meta(
                    $post_id,
                    '_sc_about_text_' . $code,
                    wp_kses_post($_POST['sc_about_text_' . $code])
                );
            } else {
                delete_post_meta( $post_id, '_sc_about_text_' . $code );
            }
        }
    }

    /**
     * Solutions Section Save
     */
    if (
        isset($_POST['sc_solutions_nonce']) &&
        wp_verify_nonce($_POST['sc_solutions_nonce'], 'sc_solutions_nonce_action')
    ) {
        $countries = array( 'usa', 'au' );
        foreach ( $countries as $code ) {
            if (isset($_POST['sc_solutions_title_' . $code])) {
                update_post_meta(
                    $post_id,
                    '_sc_solutions_title_' . $code,
                    sanitize_text_field($_POST['sc_solutions_title_' . $code])
                );
            } else {
                delete_post_meta( $post_id, '_sc_solutions_title_' . $code );
            }

            if (isset($_POST['sc_solutions_intro_' . $code])) {
                update_post_meta(
                    $post_id,
                    '_sc_solutions_intro_' . $code,
                    wp_kses_post($_POST['sc_solutions_intro_' . $code])
                );
            } else {
                delete_post_meta( $post_id, '_sc_solutions_intro_' . $code );
            }

            if (isset($_POST['sc_solutions_' . $code]) && is_array($_POST['sc_solutions_' . $code])) {
                $clean_solutions = [];
                foreach ($_POST['sc_solutions_' . $code] as $item) {
                    $title   = isset($item['title']) ? trim($item['title']) : '';
                    $content = isset($item['content']) ? trim($item['content']) : '';
                    if ($title === '' && $content === '') continue;

                    $clean_solutions[] = [
                        'title'   => sanitize_text_field($title),
                        'content' => wp_kses_post($content),
                    ];
                }
                if ( ! empty( $clean_solutions ) ) {
                    update_post_meta($post_id, '_sc_solutions_' . $code, $clean_solutions);
                } else {
                    delete_post_meta($post_id, '_sc_solutions_' . $code);
                }
            } else {
                delete_post_meta($post_id, '_sc_solutions_' . $code);
            }
        }
    }
    /**
     * Why Outsource Section Save
     */
    if (
        isset($_POST['sc_out_nonce']) &&
        wp_verify_nonce($_POST['sc_out_nonce'], 'sc_out_nonce_action')
    ) {

        // Save country-specific outsource values
        $countries = array( 'usa', 'au' );
        foreach ( $countries as $code ) {
            if (isset($_POST['sc_out_title_' . $code])) {
                update_post_meta(
                    $post_id,
                    '_sc_out_title_' . $code,
                    sanitize_text_field($_POST['sc_out_title_' . $code])
                );
            } else {
                delete_post_meta( $post_id, '_sc_out_title_' . $code );
            }

            if (isset($_POST['sc_out_left_' . $code])) {
                update_post_meta(
                    $post_id,
                    '_sc_out_left_' . $code,
                    wp_kses_post($_POST['sc_out_left_' . $code])
                );
            } else {
                delete_post_meta( $post_id, '_sc_out_left_' . $code );
            }

            if (isset($_POST['sc_out_right_' . $code])) {
                update_post_meta(
                    $post_id,
                    '_sc_out_right_' . $code,
                    wp_kses_post($_POST['sc_out_right_' . $code])
                );
            } else {
                delete_post_meta( $post_id, '_sc_out_right_' . $code );
            }
        }
    }

    /**
     * FAQ Section Save
     */
    if (
        isset($_POST['sc_faq_nonce']) &&
        wp_verify_nonce($_POST['sc_faq_nonce'], 'sc_faq_nonce_action') &&
        isset($_POST['sc_faqs']) && is_array($_POST['sc_faqs'])
    ) {
        // Save country-specific FAQ values
        $countries = array( 'usa', 'au' );
        foreach ( $countries as $code ) {
            if (isset($_POST['sc_faq_title_' . $code])) {
                update_post_meta(
                    $post_id,
                    '_sc_faq_title_' . $code,
                    sanitize_text_field($_POST['sc_faq_title_' . $code])
                );
            } else {
                delete_post_meta( $post_id, '_sc_faq_title_' . $code );
            }

            if (isset($_POST['sc_faqs_' . $code]) && is_array($_POST['sc_faqs_' . $code])) {
                $clean_faqs = [];

                foreach ($_POST['sc_faqs_' . $code] as $faq) {
                    $question = isset($faq['question']) ? trim($faq['question']) : '';
                    $answer   = isset($faq['answer']) ? trim($faq['answer']) : '';

                    if ($question === '' && $answer === '') {
                        continue;
                    }

                    $clean_faqs[] = [
                        'question' => sanitize_text_field($question),
                        'answer'   => wp_kses_post($answer),
                    ];
                }

                if ( ! empty( $clean_faqs ) ) {
                    update_post_meta($post_id, '_sc_faqs_' . $code, $clean_faqs);
                } else {
                    delete_post_meta($post_id, '_sc_faqs_' . $code);
                }
            } else {
                delete_post_meta($post_id, '_sc_faqs_' . $code);
            }
        }
    }

     if ( isset( $_POST['sc_industry_nonce'] ) &&
         wp_verify_nonce( $_POST['sc_industry_nonce'], 'sc_industry_nonce_action' ) ) {

        $countries = array( 'usa', 'au' );
        foreach ( $countries as $code ) {
            if ( isset( $_POST['sc_industry_title_' . $code] ) ) {
                update_post_meta(
                    $post_id,
                    '_sc_industry_title_' . $code,
                    sanitize_text_field( $_POST['sc_industry_title_' . $code] )
                );
            } else {
                delete_post_meta( $post_id, '_sc_industry_title_' . $code );
            }

            if ( isset( $_POST['sc_industry_items_' . $code] ) && is_array( $_POST['sc_industry_items_' . $code] ) ) {
                $clean_items = [];

                foreach ( $_POST['sc_industry_items_' . $code] as $item ) {
                    $icon  = isset( $item['icon'] )  ? trim( $item['icon'] )  : '';
                    $title = isset( $item['title'] ) ? trim( $item['title'] ) : '';
                    $desc  = isset( $item['desc'] )  ? trim( $item['desc'] )  : '';

                    if ( $icon === '' && $title === '' && $desc === '' ) {
                        continue;
                    }

                    $clean_items[] = [
                        'icon'  => esc_url_raw( $icon ),
                        'title' => sanitize_text_field( $title ),
                        'desc'  => sanitize_textarea_field( $desc ),
                    ];
                }

                if ( ! empty( $clean_items ) ) {
                    update_post_meta( $post_id, '_sc_industry_items_' . $code, $clean_items );
                } else {
                    delete_post_meta( $post_id, '_sc_industry_items_' . $code );
                }
            } else {
                delete_post_meta( $post_id, '_sc_industry_items_' . $code );
            }
        }
    }
}

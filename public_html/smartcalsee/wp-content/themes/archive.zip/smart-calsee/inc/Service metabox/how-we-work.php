<?php

function hs_add_requirements_metabox() {   
    $screen = get_current_screen();
    if ( ! $screen || $screen->id !== 'page' ) {
        return;
    }

    if ( ! isset( $_GET['post'] ) ) {
        return;
    }

    // Get the page being edited
    $current_post_id = intval( $_GET['post'] );

    // Get the how-we-work page
    $target_page = get_page_by_path( 'how-we-work' );
    if ( ! $target_page ) {
        return;
    }

    // Show only when editing the how-we-work page
    if ( $current_post_id !== $target_page->ID ) {
        return;
    }

    // Add your meta boxes
    add_meta_box(
        'hs_requirements_metabox',
        __('Understanding Your Requirements Section', 'textdomain'),
        'hs_requirements_metabox_cb',
        'page',
        'normal',
        'high'
    );

    add_meta_box(
        'hs_onboarding_metabox',
        __('Onboarding & Setup Section', 'textdomain'),
        'hs_onboarding_metabox_cb',
        'page',
        'normal',
        'high'
    );

    add_meta_box(
        'hs_security_metabox',
        __('Data Security & Compliance Section', 'textdomain'),
        'hs_security_metabox_cb',
        'page',
        'normal',
        'high'
    );

    add_meta_box(
        'hs_reporting_metabox',
        __('Reporting & Delivery Section', 'textdomain'),
        'hs_reporting_metabox_cb',
        'page',
        'normal',
        'high'
    );

    add_meta_box(
        'hs_support_metabox',
        __('Ongoing Support & Process Improvement', 'textdomain'),
        'hs_support_metabox_cb',
        'page',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'hs_add_requirements_metabox');


/*-------------------------------------
 * Section 1: Understanding Your Requirements
 *------------------------------------*/
function hs_requirements_metabox_cb($post)
{
    wp_nonce_field('hs_requirements_metabox_nonce', 'hs_requirements_metabox_nonce_field');
    wp_enqueue_media();

    $countries = array( 'usa' => 'USA', 'au' => 'Australia' );
    ?>
    <style>
    .country-tabs { display: flex; gap: 10px; margin-bottom: 20px; border-bottom: 2px solid #ddd; }
    .country-tab { padding: 10px 20px; cursor: pointer; background: #f5f5f5; border: none; border-bottom: 3px solid transparent; }
    .country-tab.active { background: #fff; border-bottom-color: #0073aa; font-weight: bold; }
    .country-content { display: none; }
    .country-content.active { display: block; }
    </style>
    
    <div class="country-tabs">
        <?php foreach ( $countries as $code => $name ) : ?>
            <button type="button" class="country-tab <?php echo $code === 'usa' ? 'active' : ''; ?>" data-country="<?php echo esc_attr( $code ); ?>">
                <?php echo esc_html( $name ); ?>
            </button>
        <?php endforeach; ?>
    </div>

    <?php foreach ( $countries as $code => $name ) : 
        $title = get_post_meta($post->ID, '_hs_req_title_' . $code, true);
        $content = get_post_meta($post->ID, '_hs_req_content_' . $code, true);
        $points = get_post_meta($post->ID, '_hs_req_points_' . $code, true);
        $image_id = get_post_meta($post->ID, '_hs_req_image_id_' . $code, true);
        
        if ( empty( $title ) ) $title = get_post_meta($post->ID, '_hs_req_title', true);
        if ( empty( $content ) ) $content = get_post_meta($post->ID, '_hs_req_content', true);
        if ( empty( $points ) ) $points = get_post_meta($post->ID, '_hs_req_points', true);
        if ( empty( $image_id ) ) $image_id = get_post_meta($post->ID, '_hs_req_image_id', true);
        
        $image_url = $image_id ? wp_get_attachment_image_url($image_id, 'large') : '';
    ?>
    <div class="country-content <?php echo $code === 'usa' ? 'active' : ''; ?>" data-country="<?php echo esc_attr( $code ); ?>">
        <h3 style="margin-top: 0;"><?php echo esc_html( $name ); ?> Requirements Section</h3>
        <div class="hs-req-wrap">
            <div class="hs-req-left">
                <div class="hs-field">
                    <label for="hs_req_title_<?php echo esc_attr( $code ); ?>">Section Title</label>
                    <input type="text" id="hs_req_title_<?php echo esc_attr( $code ); ?>" name="hs_req_title_<?php echo esc_attr( $code ); ?>" class="widefat"
                        value="<?php echo esc_attr($title); ?>">
                </div>

                <div class="hs-field">
                    <label for="hs_req_content_<?php echo esc_attr( $code ); ?>">Short Description</label>
                    <?php
                    $editor_id = 'hs_req_content_editor_' . $code;
                    wp_editor(
                        $content,
                        $editor_id,
                        array(
                            'textarea_name' => 'hs_req_content_' . $code,
                            'textarea_rows' => 5,
                            'media_buttons' => false,
                        )
                    );
                    ?>
                </div>

                <div class="hs-field">
                    <label for="hs_req_points_<?php echo esc_attr( $code ); ?>">Bullet Points (use list button)</label>
                    <?php
                    $editor_id = 'hs_req_points_editor_' . $code;
                    wp_editor(
                        $points,
                        $editor_id,
                        array(
                            'textarea_name' => 'hs_req_points_' . $code,
                            'textarea_rows' => 5,
                            'media_buttons' => false,
                        )
                    );
                    ?>
                </div>
            </div>

            <div class="hs-req-right">
                <label>Section Image</label>
                <div class="hs-req-image-preview">
                    <?php if ($image_url) : ?>
                        <img src="<?php echo esc_url($image_url); ?>" alt="">
                    <?php endif; ?>
                </div>
                <input type="hidden" id="hs_req_image_id_<?php echo esc_attr( $code ); ?>" name="hs_req_image_id_<?php echo esc_attr( $code ); ?>"
                    value="<?php echo esc_attr($image_id); ?>">
                <div class="hs-req-image-buttons">
                    <button type="button" class="button hs-upload-req" data-country="<?php echo esc_attr( $code ); ?>">Upload / Choose Image</button>
                    <button type="button" class="button hs-remove-req" data-country="<?php echo esc_attr( $code ); ?>">Remove Image</button>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>

   <script>
jQuery(function($){
    // Country tab switching
    $('.country-tab').on('click', function() {
        var country = $(this).data('country');
        $('.country-tab').removeClass('active');
        $(this).addClass('active');
        $('.country-content').removeClass('active');
        $('.country-content[data-country="' + country + '"]').addClass('active');
    });

    var frames = {};

    $(document).on('click', '.hs-upload-req', function(e){
        e.preventDefault();
        var country = $(this).data('country');
        const $wrap = $(this).closest('.hs-req-wrap');

        if (!frames['req_' + country]) {
            frames['req_' + country] = wp.media({
                title: 'Select or Upload Image',
                button: { text: 'Use this image' },
                multiple: false
            });

            frames['req_' + country].on('select', function(){
                const attachment = frames['req_' + country].state().get('selection').first().toJSON();
                $wrap.find('#hs_req_image_id_' + country).val(attachment.id);
                $wrap.find('.hs-req-image-preview').html('<img src="'+attachment.url+'" />');
            });
        }

        frames['req_' + country].open();
    });

    $(document).on('click', '.hs-remove-req', function(){
        var country = $(this).data('country');
        const $wrap = $(this).closest('.hs-req-wrap');
        $wrap.find('#hs_req_image_id_' + country).val('');
        $wrap.find('.hs-req-image-preview').html('');
    });
});
</script>
<?php
}


/*-------------------------------------
 * Section 2: Onboarding & Setup
 *------------------------------------*/
function hs_onboarding_metabox_cb($post)
{
    wp_nonce_field('hs_onboarding_metabox_nonce', 'hs_onboarding_metabox_nonce_field');
    wp_enqueue_media();

    $countries = array( 'usa' => 'USA', 'au' => 'Australia' );
    ?>
    <style>
    .country-tabs { display: flex; gap: 10px; margin-bottom: 20px; border-bottom: 2px solid #ddd; }
    .country-tab { padding: 10px 20px; cursor: pointer; background: #f5f5f5; border: none; border-bottom: 3px solid transparent; }
    .country-tab.active { background: #fff; border-bottom-color: #0073aa; font-weight: bold; }
    .country-content { display: none; }
    .country-content.active { display: block; }
    </style>
    
    <div class="country-tabs">
        <?php foreach ( $countries as $code => $name ) : ?>
            <button type="button" class="country-tab <?php echo $code === 'usa' ? 'active' : ''; ?>" data-country="<?php echo esc_attr( $code ); ?>">
                <?php echo esc_html( $name ); ?>
            </button>
        <?php endforeach; ?>
    </div>

    <?php foreach ( $countries as $code => $name ) : 
        $title = get_post_meta($post->ID, '_hs_onboarding_title_' . $code, true);
        $content = get_post_meta($post->ID, '_hs_onboarding_content_' . $code, true);
        $points = get_post_meta($post->ID, '_hs_onboarding_points_' . $code, true);
        $image_id = get_post_meta($post->ID, '_hs_onboarding_image_id_' . $code, true);
        
        if ( empty( $title ) ) $title = get_post_meta($post->ID, '_hs_onboarding_title', true);
        if ( empty( $content ) ) $content = get_post_meta($post->ID, '_hs_onboarding_content', true);
        if ( empty( $points ) ) $points = get_post_meta($post->ID, '_hs_onboarding_points', true);
        if ( empty( $image_id ) ) $image_id = get_post_meta($post->ID, '_hs_onboarding_image_id', true);
        
        $image_url = $image_id ? wp_get_attachment_image_url($image_id, 'large') : '';
    ?>
    <div class="country-content <?php echo $code === 'usa' ? 'active' : ''; ?>" data-country="<?php echo esc_attr( $code ); ?>">
        <h3 style="margin-top: 0;"><?php echo esc_html( $name ); ?> Onboarding Section</h3>
        <div class="hs-req-wrap">

        <div class="hs-req-left">

            <div class="hs-field">
                <label>Section Title</label>
                <input type="text" class="widefat" name="hs_onboarding_title_<?php echo esc_attr( $code ); ?>"
                    value="<?php echo esc_attr($title); ?>">
            </div>

            <div class="hs-field">
                <label>Short Description</label>
                <?php
                $editor_id = 'hs_onboarding_desc_editor_' . $code;
                wp_editor($content, $editor_id, [
                    'textarea_name' => 'hs_onboarding_content_' . $code,
                    'textarea_rows' => 5,
                    'media_buttons' => false
                ]);
                ?>
            </div>

            <div class="hs-field">
                <label>Bullet Points (use list formatting)</label>
                <?php
                $editor_id = 'hs_onboarding_points_editor_' . $code;
                wp_editor($points, $editor_id, [
                    'textarea_name' => 'hs_onboarding_points_' . $code,
                    'textarea_rows' => 5,
                    'media_buttons' => false
                ]);
                ?>
            </div>

        </div>

        <div class="hs-req-right">
            <label>Section Image</label>

            <div class="hs-req-image-preview">
                <?php if ($image_url) : ?>
                    <img src="<?php echo esc_url($image_url); ?>" alt="">
                <?php endif; ?>
            </div>

            <input type="hidden" id="hs_onboarding_image_id_<?php echo esc_attr( $code ); ?>" name="hs_onboarding_image_id_<?php echo esc_attr( $code ); ?>"
                value="<?php echo esc_attr($image_id); ?>">

            <div class="hs-req-image-buttons">
                <button type="button" class="button hs-upload-onboarding" data-country="<?php echo esc_attr( $code ); ?>">Upload / Choose Image</button>
                <button type="button" class="button hs-remove-onboarding" data-country="<?php echo esc_attr( $code ); ?>">Remove Image</button>
            </div>
        </div>

    </div>
    </div>
    <?php endforeach; ?>

    <script>
jQuery(function($){
    // Country tab switching
    $('.country-tab').on('click', function() {
        var country = $(this).data('country');
        $('.country-tab').removeClass('active');
        $(this).addClass('active');
        $('.country-content').removeClass('active');
        $('.country-content[data-country="' + country + '"]').addClass('active');
    });

    var frames = {};

    $(document).on('click', '.hs-upload-onboarding', function(e){
        e.preventDefault();
        var country = $(this).data('country');
        const $wrap = $(this).closest('.hs-req-wrap');

        if (!frames['onboarding_' + country]) {
            frames['onboarding_' + country] = wp.media({
                title: 'Select or Upload Image',
                button: { text: 'Use this image' },
                multiple: false
            });

            frames['onboarding_' + country].on('select', function(){
                const attachment = frames['onboarding_' + country].state().get('selection').first().toJSON();
                $wrap.find('#hs_onboarding_image_id_' + country).val(attachment.id);
                $wrap.find('.hs-req-image-preview').html('<img src="'+attachment.url+'" />');
            });
        }

        frames['onboarding_' + country].open();
    });

    $(document).on('click', '.hs-remove-onboarding', function(){
        var country = $(this).data('country');
        const $wrap = $(this).closest('.hs-req-wrap');
        $wrap.find('#hs_onboarding_image_id_' + country).val('');
        $wrap.find('.hs-req-image-preview').html('');
    });
});
</script>

<?php
}


/*-------------------------------------
 * Section 3: Data Security & Compliance (repeater)
 *------------------------------------*/
function hs_security_metabox_cb($post)
{
    wp_nonce_field('hs_security_metabox_nonce', 'hs_security_metabox_nonce_field');
    wp_enqueue_media();

    $countries = array( 'usa' => 'USA', 'au' => 'Australia' );
    ?>
    <style>
    .country-tabs { display: flex; gap: 10px; margin-bottom: 20px; border-bottom: 2px solid #ddd; }
    .country-tab { padding: 10px 20px; cursor: pointer; background: #f5f5f5; border: none; border-bottom: 3px solid transparent; }
    .country-tab.active { background: #fff; border-bottom-color: #0073aa; font-weight: bold; }
    .country-content { display: none; }
    .country-content.active { display: block; }
    </style>
    
    <div class="country-tabs">
        <?php foreach ( $countries as $code => $name ) : ?>
            <button type="button" class="country-tab <?php echo $code === 'usa' ? 'active' : ''; ?>" data-country="<?php echo esc_attr( $code ); ?>">
                <?php echo esc_html( $name ); ?>
            </button>
        <?php endforeach; ?>
    </div>

    <?php foreach ( $countries as $code => $name ) : 
        // main fields
        $title = get_post_meta($post->ID, '_hs_sec_title_' . $code, true);
        $sub_title = get_post_meta($post->ID, '_hs_sec_sub_title_' . $code, true);
        $intro = get_post_meta($post->ID, '_hs_sec_intro_' . $code, true);
        $image_id = get_post_meta($post->ID, '_hs_sec_image_id_' . $code, true);
        
        if ( empty( $title ) ) $title = get_post_meta($post->ID, '_hs_sec_title', true);
        if ( empty( $sub_title ) ) $sub_title = get_post_meta($post->ID, '_hs_sec_sub_title', true);
        if ( empty( $intro ) ) $intro = get_post_meta($post->ID, '_hs_sec_intro', true);
        if ( empty( $image_id ) ) $image_id = get_post_meta($post->ID, '_hs_sec_image_id', true);
        
        $image_url = $image_id ? wp_get_attachment_image_url($image_id, 'large') : '';

        // repeater array
        $features = get_post_meta($post->ID, '_hs_security_features_' . $code, true);
        if ( empty( $features ) ) $features = get_post_meta($post->ID, '_hs_security_features', true);
        if (!is_array($features)) {
            $features = [];
        }
    ?>
    <div class="country-content <?php echo $code === 'usa' ? 'active' : ''; ?>" data-country="<?php echo esc_attr( $code ); ?>">
        <h3 style="margin-top: 0;"><?php echo esc_html( $name ); ?> Data Security & Compliance Section</h3>
        <div class="hs-sec-wrap">

        <div class="hs-sec-main">

            <div class="hs-field">
                <label>Section Title</label>
                <input type="text" class="widefat"
                    name="hs_sec_title_<?php echo esc_attr( $code ); ?>"
                    value="<?php echo esc_attr($title); ?>"
                    placeholder="Data Security & Compliance Protocols">
            </div>

            <div class="hs-field">
                <label>Sub Heading (green text)</label>
                <input type="text" class="widefat"
                    name="hs_sec_sub_title_<?php echo esc_attr( $code ); ?>"
                    value="<?php echo esc_attr($sub_title); ?>"
                    placeholder="Your Data, Protected Like a Vault — Every Second of the Day">
            </div>

            <div class="hs-field">
                <label>Intro Description</label>
                <?php
                $editor_id = 'hs_sec_intro_editor_' . $code;
                wp_editor(
                    $intro,
                    $editor_id,
                    [
                        'textarea_name' => 'hs_sec_intro_' . $code,
                        'textarea_rows' => 5,
                        'media_buttons' => false,
                    ]
                );
                ?>
            </div>

            <hr />

            <h3 style="margin-top:10px;">Feature Boxes</h3>
            <p style="margin-top:-5px;">Use "Add Feature Box" to add more items.</p>

            <div id="hs-feature-wrapper-<?php echo esc_attr( $code ); ?>">
                <?php foreach ($features as $index => $feature) : ?>
                    <div class="hs-feature-item">
                        <span class="hs-remove-feature" onclick="this.parentNode.remove()">✖</span>

                        <div class="hs-field">
                            <label>Feature Title</label>
                            <input type="text" class="widefat"
                                name="hs_security_features_<?php echo esc_attr( $code ); ?>[<?php echo esc_attr($index); ?>][title]"
                                value="<?php echo esc_attr($feature['title'] ?? ''); ?>">
                        </div>

                        <div class="hs-field">
                            <label>Bullet Points (use list in editor)</label>
                            <?php
                            $editor_id = 'hs_security_features_' . $code . '_' . $index;
                            wp_editor(
                                $feature['content'] ?? '',
                                $editor_id,
                                [
                                    'textarea_name' => 'hs_security_features_' . $code . '[' . $index . '][content]',
                                    'textarea_rows' => 4,
                                    'media_buttons' => false,
                                ]
                            );
                            ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <button type="button" class="button hs-add-feature-btn" data-country="<?php echo esc_attr( $code ); ?>">+ Add Feature Box</button>

        </div>

        <div class="hs-sec-image">
            <div class="hs-field">
                <label>Section Image</label>
                <div class="hs-req-image-preview">
                    <?php if ($image_url) : ?>
                        <img src="<?php echo esc_url($image_url); ?>" alt="">
                    <?php endif; ?>
                </div>

                <input type="hidden" id="hs_sec_image_id_<?php echo esc_attr( $code ); ?>" name="hs_sec_image_id_<?php echo esc_attr( $code ); ?>"
                    value="<?php echo esc_attr($image_id); ?>">

                <div style="margin-top:10px;">
                    <button type="button" class="button hs-upload-security" data-country="<?php echo esc_attr( $code ); ?>">Upload / Choose Image</button>
                    <button type="button" class="button hs-remove-security" data-country="<?php echo esc_attr( $code ); ?>">Remove Image</button>
                </div>
            </div>
        </div>

    </div><!-- /.hs-sec-wrap -->
    </div>
    <?php endforeach; ?>

    <script>
        jQuery(function($) {
            // Country tab switching
            $('.country-tab').on('click', function() {
                var country = $(this).data('country');
                $('.country-tab').removeClass('active');
                $(this).addClass('active');
                $('.country-content').removeClass('active');
                $('.country-content[data-country="' + country + '"]').addClass('active');
            });

            var frames = {};
            var featureIndices = {};

            // media uploader for security image
            $(document).on('click', '.hs-upload-security', function(e) {
                e.preventDefault();
                var country = $(this).data('country');
                const $wrap = $(this).closest('.hs-sec-wrap');

                if (!frames['security_' + country]) {
                    frames['security_' + country] = wp.media({
                        title: 'Select or Upload Image',
                        button: {
                            text: 'Use this image'
                        },
                        multiple: false
                    });

                    frames['security_' + country].on('select', function() {
                        const attachment = frames['security_' + country].state().get('selection').first().toJSON();
                        $wrap.find('#hs_sec_image_id_' + country).val(attachment.id);
                        $wrap.find('.hs-req-image-preview').html('<img src="' + attachment.url + '" />');
                    });
                }

                frames['security_' + country].open();
            });

            $(document).on('click', '.hs-remove-security', function() {
                var country = $(this).data('country');
                const $wrap = $(this).closest('.hs-sec-wrap');
                $wrap.find('#hs_sec_image_id_' + country).val('');
                $wrap.find('.hs-req-image-preview').html('');
            });

            // repeater: add new feature box
            $(document).on('click', '.hs-add-feature-btn', function() {
                var country = $(this).data('country');
                if (!featureIndices[country]) {
                    featureIndices[country] = $('#hs-feature-wrapper-' + country + ' .hs-feature-item').length;
                }
                var index = featureIndices[country];
                const wrapper = $('#hs-feature-wrapper-' + country);

                const html = '<div class="hs-feature-item">' +
                    '<span class="hs-remove-feature" onclick="this.parentNode.remove()">✖</span>' +
                    '<div class="hs-field">' +
                    '<label>Feature Title</label>' +
                    '<input type="text" class="widefat" name="hs_security_features_' + country + '[' + index + '][title]">' +
                    '</div>' +
                    '<div class="hs-field">' +
                    '<label>Bullet Points (use list in editor)</label>' +
                    '<textarea id="hs_security_features_' + country + '_' + index + '" class="widefat" rows="4" name="hs_security_features_' + country + '[' + index + '][content]"></textarea>' +
                    '</div>' +
                    '</div>';

                wrapper.append(html);
                
                // Initialize wp_editor for the new textarea
                if (typeof wp !== 'undefined' && wp.editor) {
                    var editorId = 'hs_security_features_' + country + '_' + index;
                    wp.editor.initialize(editorId, {
                        tinymce: {
                            wpautop: true,
                            toolbar1: 'bold,italic,bullist,numlist,link,unlink,undo,redo',
                        },
                        quicktags: true,
                        mediaButtons: false
                    });
                }
                
                featureIndices[country]++;
            });
        });
    </script>

<?php
}

function hs_reporting_metabox_cb($post)
{

    wp_nonce_field('hs_reporting_metabox_nonce', 'hs_reporting_metabox_nonce_field');

    $title     = get_post_meta($post->ID, '_hs_reporting_title', true);
    $content   = get_post_meta($post->ID, '_hs_reporting_content', true);
    $points    = get_post_meta($post->ID, '_hs_reporting_points', true);
    $image_id  = get_post_meta($post->ID, '_hs_reporting_image_id', true);
    $image_url = $image_id ? wp_get_attachment_image_url($image_id, 'large') : '';

    wp_enqueue_media();
?>

    <div class="hs-req-wrap">

        <!-- LEFT: IMAGE (like design) -->
        <div class="hs-req-right">
            <label>Section Image</label>

            <div class="hs-req-image-preview">
                <?php if ($image_url) : ?>
                    <img src="<?php echo esc_url($image_url); ?>" alt="">
                <?php endif; ?>
            </div>

            <input type="hidden" id="hs_reporting_image_id" name="hs_reporting_image_id"
                value="<?php echo esc_attr($image_id); ?>">

            <div class="hs-req-image-buttons">
                <button type="button" class="button hs-upload-reporting">Upload / Choose Image</button>
                <button type="button" class="button hs-remove-reporting">Remove Image</button>
            </div>
        </div>

        <!-- RIGHT: TEXT -->
        <div class="hs-req-left">

            <div class="hs-field">
                <label>Section Title</label>
                <input type="text" class="widefat" name="hs_reporting_title"
                    value="<?php echo esc_attr($title); ?>"
                    placeholder="Reporting & Delivery">
            </div>

            <div class="hs-field">
                <label>Short Description</label>
                <?php
                wp_editor(
                    $content,
                    'hs_reporting_desc_editor',
                    [
                        'textarea_name' => 'hs_reporting_content',
                        'textarea_rows' => 5,
                        'media_buttons' => false,
                    ]
                );
                ?>
            </div>

            <div class="hs-field">
                <label>Bullet Points (use list icon)</label>
                <?php
                wp_editor(
                    $points,
                    'hs_reporting_points_editor',
                    [
                        'textarea_name' => 'hs_reporting_points',
                        'textarea_rows' => 4,
                        'media_buttons' => false,
                    ]
                );
                ?>
            </div>

        </div>

    </div>

  <script>
jQuery(function($){

    let frame;

    $('.hs-upload-reporting').on('click', function(e){
        e.preventDefault();

        const $wrap = $(this).closest('.hs-req-wrap');

        if (frame) {
            frame.open();
            return;
        }

        frame = wp.media({
            title: 'Select or Upload Image',
            button: { text: 'Use this image' },
            multiple: false
        });

        frame.on('select', function(){
            const attachment = frame.state().get('selection').first().toJSON();
            $wrap.find('#hs_reporting_image_id').val(attachment.id);
            $wrap.find('.hs-req-image-preview').html('<img src="'+attachment.url+'" />');
        });

        frame.open();
    });

    $('.hs-remove-reporting').on('click', function(){
        const $wrap = $(this).closest('.hs-req-wrap');
        $wrap.find('#hs_reporting_image_id').val('');
        $wrap.find('.hs-req-image-preview').html('');
    });

});
</script>

<?php
}

function hs_support_metabox_cb( $post ) {

    wp_nonce_field( 'hs_support_metabox_nonce', 'hs_support_metabox_nonce_field' );

    $title     = get_post_meta( $post->ID, '_hs_support_title', true );
    $content   = get_post_meta( $post->ID, '_hs_support_content', true );
    $points    = get_post_meta( $post->ID, '_hs_support_points', true );
    $image_id  = get_post_meta( $post->ID, '_hs_support_image_id', true );
    $image_url = $image_id ? wp_get_attachment_image_url( $image_id, 'large' ) : '';

    wp_enqueue_media();
    ?>

    <div class="hs-req-wrap">

        <!-- LEFT: TEXT -->
        <div class="hs-req-left">

            <div class="hs-field">
                <label>Section Title</label>
                <input type="text" class="widefat" name="hs_support_title"
                       value="<?php echo esc_attr( $title ); ?>"
                       placeholder="Ongoing Support & Process Improvement">
            </div>

            <div class="hs-field">
                <label>Short Description</label>
                <?php
                wp_editor(
                    $content,
                    'hs_support_content_editor',
                    [
                        'textarea_name' => 'hs_support_content',
                        'textarea_rows' => 5,
                        'media_buttons' => false,
                    ]
                );
                ?>
            </div>

            <div class="hs-field">
                <label>Bullet Points (use list button)</label>
                <?php
                wp_editor(
                    $points,
                    'hs_support_points_editor',
                    [
                        'textarea_name' => 'hs_support_points',
                        'textarea_rows' => 4,
                        'media_buttons' => false,
                    ]
                );
                ?>
            </div>

        </div>

        <!-- RIGHT: IMAGE -->
        <div class="hs-req-right">
            <label>Section Image</label>

            <div class="hs-req-image-preview">
                <?php if ( $image_url ) : ?>
                    <img src="<?php echo esc_url( $image_url ); ?>" alt="">
                <?php endif; ?>
            </div>

            <input type="hidden" id="hs_support_image_id" name="hs_support_image_id"
                   value="<?php echo esc_attr( $image_id ); ?>">

            <div class="hs-req-image-buttons">
                <button type="button" class="button hs-upload-support">Upload / Choose Image</button>
                <button type="button" class="button hs-remove-support">Remove Image</button>
            </div>
        </div>

    </div>

  <script>
jQuery(function($){
    let frame;

    $('.hs-upload-support').on('click', function(e){
        e.preventDefault();

        const $wrap = $(this).closest('.hs-req-wrap');

        if (frame) {
            frame.open();
            return;
        }

        frame = wp.media({
            title: 'Select or Upload Image',
            button: { text: 'Use this image' },
            multiple: false
        });

        frame.on('select', function(){
            const attachment = frame.state().get('selection').first().toJSON();
            $wrap.find('#hs_support_image_id').val(attachment.id);
            $wrap.find('.hs-req-image-preview').html('<img src="'+attachment.url+'" />');
        });

        frame.open();
    });

    $('.hs-remove-support').on('click', function(){
        const $wrap = $(this).closest('.hs-req-wrap');
        $wrap.find('#hs_support_image_id').val('');
        $wrap.find('.hs-req-image-preview').html('');
    });
});
</script>

    <?php
}

/*-------------------------------------
 * Save all meta box data
 *------------------------------------*/
function hs_save_requirements_metabox($post_id)
{

    // At least one valid nonce must be present
    $valid_nonce = false;

    if (
        isset($_POST['hs_requirements_metabox_nonce_field']) &&
        wp_verify_nonce($_POST['hs_requirements_metabox_nonce_field'], 'hs_requirements_metabox_nonce')
    ) {
        $valid_nonce = true;
    }

    if (
        isset($_POST['hs_onboarding_metabox_nonce_field']) &&
        wp_verify_nonce($_POST['hs_onboarding_metabox_nonce_field'], 'hs_onboarding_metabox_nonce')
    ) {
        $valid_nonce = true;
    }

    if (
        isset($_POST['hs_security_metabox_nonce_field']) &&
        wp_verify_nonce($_POST['hs_security_metabox_nonce_field'], 'hs_security_metabox_nonce')
    ) {
        $valid_nonce = true;
    }
    if (
        isset($_POST['hs_reporting_metabox_nonce_field']) &&
        wp_verify_nonce($_POST['hs_reporting_metabox_nonce_field'], 'hs_reporting_metabox_nonce')
    ) {
        $valid_nonce = true;
    }
    if ( isset($_POST['hs_support_metabox_nonce_field']) &&
     wp_verify_nonce($_POST['hs_support_metabox_nonce_field'], 'hs_support_metabox_nonce') ) {
    $valid_nonce = true;
}    

    if (!$valid_nonce) {
        return;
    }

    // Autosave check
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    // Permissions
    if (isset($_POST['post_type']) && 'page' === $_POST['post_type']) {
        if (!current_user_can('edit_page', $post_id)) {
            return;
        }
    } else {
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
    }

    // Save country-specific values for all sections
    $countries = array( 'usa', 'au' );
    
    foreach ( $countries as $code ) {
        /*--------- Section 1: Requirements ---------*/
        if (isset($_POST['hs_req_title_' . $code])) {
            update_post_meta($post_id, '_hs_req_title_' . $code, sanitize_text_field($_POST['hs_req_title_' . $code]));
        } else {
            delete_post_meta($post_id, '_hs_req_title_' . $code);
        }
        if (isset($_POST['hs_req_content_' . $code])) {
            update_post_meta($post_id, '_hs_req_content_' . $code, wp_kses_post($_POST['hs_req_content_' . $code]));
        } else {
            delete_post_meta($post_id, '_hs_req_content_' . $code);
        }
        if (isset($_POST['hs_req_points_' . $code])) {
            update_post_meta($post_id, '_hs_req_points_' . $code, wp_kses_post($_POST['hs_req_points_' . $code]));
        } else {
            delete_post_meta($post_id, '_hs_req_points_' . $code);
        }
        if (isset($_POST['hs_req_image_id_' . $code])) {
            update_post_meta($post_id, '_hs_req_image_id_' . $code, intval($_POST['hs_req_image_id_' . $code]));
        } else {
            delete_post_meta($post_id, '_hs_req_image_id_' . $code);
        }

        /*--------- Section 2: Onboarding ---------*/
        if (isset($_POST['hs_onboarding_title_' . $code])) {
            update_post_meta($post_id, '_hs_onboarding_title_' . $code, sanitize_text_field($_POST['hs_onboarding_title_' . $code]));
        } else {
            delete_post_meta($post_id, '_hs_onboarding_title_' . $code);
        }
        if (isset($_POST['hs_onboarding_content_' . $code])) {
            update_post_meta($post_id, '_hs_onboarding_content_' . $code, wp_kses_post($_POST['hs_onboarding_content_' . $code]));
        } else {
            delete_post_meta($post_id, '_hs_onboarding_content_' . $code);
        }
        if (isset($_POST['hs_onboarding_points_' . $code])) {
            update_post_meta($post_id, '_hs_onboarding_points_' . $code, wp_kses_post($_POST['hs_onboarding_points_' . $code]));
        } else {
            delete_post_meta($post_id, '_hs_onboarding_points_' . $code);
        }
        if (isset($_POST['hs_onboarding_image_id_' . $code])) {
            update_post_meta($post_id, '_hs_onboarding_image_id_' . $code, intval($_POST['hs_onboarding_image_id_' . $code]));
        } else {
            delete_post_meta($post_id, '_hs_onboarding_image_id_' . $code);
        }
    }

        /*--------- Section 3: Security ---------*/
        $sec_title = isset($_POST['hs_sec_title_' . $code]) ? sanitize_text_field($_POST['hs_sec_title_' . $code]) : '';
        $sec_sub_title = isset($_POST['hs_sec_sub_title_' . $code]) ? sanitize_text_field($_POST['hs_sec_sub_title_' . $code]) : '';
        $sec_intro = isset($_POST['hs_sec_intro_' . $code]) ? wp_kses_post($_POST['hs_sec_intro_' . $code]) : '';
        $sec_image_id = isset($_POST['hs_sec_image_id_' . $code]) ? intval($_POST['hs_sec_image_id_' . $code]) : '';

        if ( ! empty( $sec_title ) || ! empty( $sec_sub_title ) || ! empty( $sec_intro ) || ! empty( $sec_image_id ) ) {
            update_post_meta($post_id, '_hs_sec_title_' . $code, $sec_title);
            update_post_meta($post_id, '_hs_sec_sub_title_' . $code, $sec_sub_title);
            update_post_meta($post_id, '_hs_sec_intro_' . $code, $sec_intro);
            update_post_meta($post_id, '_hs_sec_image_id_' . $code, $sec_image_id);
        } else {
            delete_post_meta($post_id, '_hs_sec_title_' . $code);
            delete_post_meta($post_id, '_hs_sec_sub_title_' . $code);
            delete_post_meta($post_id, '_hs_sec_intro_' . $code);
            delete_post_meta($post_id, '_hs_sec_image_id_' . $code);
        }

        /*--------- Section 3 repeater: Security Features ---------*/
        if (isset($_POST['hs_security_features_' . $code]) && is_array($_POST['hs_security_features_' . $code])) {
            $clean = [];
            foreach ($_POST['hs_security_features_' . $code] as $feature) {
                if (empty($feature['title']) && empty($feature['content'])) {
                    continue;
                }
                $clean[] = [
                    'title'   => sanitize_text_field($feature['title'] ?? ''),
                    'content' => wp_kses_post($feature['content'] ?? ''),
                ];
            }
            if ( ! empty( $clean ) ) {
                update_post_meta($post_id, '_hs_security_features_' . $code, $clean);
            } else {
                delete_post_meta($post_id, '_hs_security_features_' . $code);
            }
        } else {
            delete_post_meta($post_id, '_hs_security_features_' . $code);
        }

        /*--------- Section 4: Reporting ---------*/
        if (isset($_POST['hs_reporting_title_' . $code])) {
            update_post_meta($post_id, '_hs_reporting_title_' . $code, sanitize_text_field($_POST['hs_reporting_title_' . $code]));
        } else {
            delete_post_meta($post_id, '_hs_reporting_title_' . $code);
        }
        if (isset($_POST['hs_reporting_content_' . $code])) {
            update_post_meta($post_id, '_hs_reporting_content_' . $code, wp_kses_post($_POST['hs_reporting_content_' . $code]));
        } else {
            delete_post_meta($post_id, '_hs_reporting_content_' . $code);
        }
        if (isset($_POST['hs_reporting_points_' . $code])) {
            update_post_meta($post_id, '_hs_reporting_points_' . $code, wp_kses_post($_POST['hs_reporting_points_' . $code]));
        } else {
            delete_post_meta($post_id, '_hs_reporting_points_' . $code);
        }
        if (isset($_POST['hs_reporting_image_id_' . $code])) {
            update_post_meta($post_id, '_hs_reporting_image_id_' . $code, intval($_POST['hs_reporting_image_id_' . $code]));
        } else {
            delete_post_meta($post_id, '_hs_reporting_image_id_' . $code);
        }

        /*--------- Section 5: Support ---------*/
        if (isset($_POST['hs_support_title_' . $code])) {
            update_post_meta($post_id, '_hs_support_title_' . $code, sanitize_text_field($_POST['hs_support_title_' . $code]));
        } else {
            delete_post_meta($post_id, '_hs_support_title_' . $code);
        }
        if (isset($_POST['hs_support_content_' . $code])) {
            update_post_meta($post_id, '_hs_support_content_' . $code, wp_kses_post($_POST['hs_support_content_' . $code]));
        } else {
            delete_post_meta($post_id, '_hs_support_content_' . $code);
        }
        if (isset($_POST['hs_support_points_' . $code])) {
            update_post_meta($post_id, '_hs_support_points_' . $code, wp_kses_post($_POST['hs_support_points_' . $code]));
        } else {
            delete_post_meta($post_id, '_hs_support_points_' . $code);
        }
        if (isset($_POST['hs_support_image_id_' . $code])) {
            update_post_meta($post_id, '_hs_support_image_id_' . $code, intval($_POST['hs_support_image_id_' . $code]));
        } else {
            delete_post_meta($post_id, '_hs_support_image_id_' . $code);
        }
    }

add_action('save_post', 'hs_save_requirements_metabox');

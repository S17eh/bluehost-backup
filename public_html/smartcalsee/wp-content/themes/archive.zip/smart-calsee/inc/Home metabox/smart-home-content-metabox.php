<?php 

add_action( 'add_meta_boxes', 'smart_contact_add_meta_box' );
function smart_contact_add_meta_box() {
    $screen = get_current_screen();

    if ( $screen && $screen->id === 'page' && isset( $_GET['post'] ) ) {
        $homepage_id = get_option( 'page_on_front' );
        $current_post_id = intval( $_GET['post'] );

        if ( $current_post_id === intval( $homepage_id ) ) {
            add_meta_box(
                'smart_contact_settings',     // ID
                'Contact section',            // Title
                'smart_contact_render_box',   // Callback
                'page',                       // Screen
                'normal',                     // Context
                'high'                        // Priority
            );
        }
    }
}

function smart_contact_render_box( $post ) {
    wp_nonce_field( 'smart_contact_meta_nonce_action', 'smart_contact_meta_nonce' );

    $countries = array( 'usa' => 'USA', 'au' => 'Australia' );
    ?>
    <style>
    .country-tabs { display: flex; gap: 10px; margin-bottom: 20px; border-bottom: 2px solid #ddd; }
    .country-tab { padding: 10px 20px; cursor: pointer; background: #f5f5f5; border: none; border-bottom: 3px solid transparent; }
    .country-tab.active { background: #fff; border-bottom-color: #0073aa; font-weight: bold; }
    .country-content { display: none; }
    .country-content.active { display: block; }
    </style>
    
    <div class="country-tabs">
        <?php foreach ( $countries as $code => $name ) : ?>
            <button type="button" class="country-tab <?php echo $code === 'usa' ? 'active' : ''; ?>" data-country="<?php echo esc_attr( $code ); ?>">
                <?php echo esc_html( $name ); ?>
            </button>
        <?php endforeach; ?>
    </div>

    <?php foreach ( $countries as $code => $name ) : 
        // Load country-specific values
        $contact_title = get_post_meta( $post->ID, '_contact_home_title_' . $code, true );
        $contact_description = get_post_meta( $post->ID, '_contact_home_description_' . $code, true );
        $button_text = get_post_meta( $post->ID, '_contact_button_text_' . $code, true );
        $button_link = get_post_meta( $post->ID, '_contact_button_link_' . $code, true );
        
        // Fallback to default values if country-specific not set
        if ( empty( $contact_title ) ) $contact_title = get_post_meta( $post->ID, '_contact_home_title', true );
        if ( empty( $contact_description ) ) $contact_description = get_post_meta( $post->ID, '_contact_home_description', true );
        if ( empty( $button_text ) ) $button_text = get_post_meta( $post->ID, '_contact_button_text', true );
        if ( empty( $button_link ) ) $button_link = get_post_meta( $post->ID, '_contact_button_link', true );
    ?>
    <div class="country-content <?php echo $code === 'usa' ? 'active' : ''; ?>" data-country="<?php echo esc_attr( $code ); ?>">
        <h3 style="margin-top: 0;"><?php echo esc_html( $name ); ?> Contact Section</h3>
        
        <p>
            <label for="contact-title-<?php echo esc_attr( $code ); ?>"><strong>Contact Title</strong></label><br>
            <input type="text" name="contact_home_title_<?php echo esc_attr( $code ); ?>" id="contact-title-<?php echo esc_attr( $code ); ?>" value="<?php echo esc_attr( $contact_title ); ?>" style="width:100%;">
        </p>

        <p>
            <label for="contact-description-<?php echo esc_attr( $code ); ?>"><strong>Contact Description</strong></label><br>
            <?php
            $editor_id = 'contact-description-' . $code;
            $settings = array(
                'textarea_name' => 'contact_home_description_' . $code,
                'media_buttons' => true,
                'textarea_rows' => 6,
                'teeny' => false,
            );
            wp_editor( $contact_description, $editor_id, $settings );
            ?>
        </p>

        <hr>

        <h4>Button Settings</h4>
        <p>
            <label for="contact-button-text-<?php echo esc_attr( $code ); ?>"><strong>Button Text</strong></label><br>
            <input type="text" name="contact_button_text_<?php echo esc_attr( $code ); ?>" id="contact-button-text-<?php echo esc_attr( $code ); ?>" value="<?php echo esc_attr( $button_text ); ?>" style="width:100%;">
        </p>

        <p>
            <label for="contact-button-link-<?php echo esc_attr( $code ); ?>"><strong>Button Link</strong></label><br>
            <input type="url" name="contact_button_link_<?php echo esc_attr( $code ); ?>" id="contact-button-link-<?php echo esc_attr( $code ); ?>" value="<?php echo esc_attr( $button_link ); ?>" style="width:100%;">
        </p>
    </div>
    <?php endforeach; ?>
    
    <script>
    jQuery(document).ready(function($) {
        $('.country-tab').on('click', function() {
            var country = $(this).data('country');
            $('.country-tab').removeClass('active');
            $(this).addClass('active');
            $('.country-content').removeClass('active');
            $('.country-content[data-country="' + country + '"]').addClass('active');
        });
    });
    </script>
    <?php
}

/**
 * Save meta box data
 */
add_action( 'save_post', 'smart_contact_save_meta_box' );
function smart_contact_save_meta_box( $post_id ) {
    // Verify nonce
    if ( ! isset( $_POST['smart_contact_meta_nonce'] ) ||
         ! wp_verify_nonce( $_POST['smart_contact_meta_nonce'], 'smart_contact_meta_nonce_action' ) ) {
        return;
    }

    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    // Save country-specific values
    $countries = array( 'usa', 'au' );
    
    foreach ( $countries as $code ) {
        if ( isset( $_POST['contact_home_title_' . $code] ) ) {
            update_post_meta( $post_id, '_contact_home_title_' . $code, sanitize_text_field( wp_unslash( $_POST['contact_home_title_' . $code] ) ) );
        } else {
            delete_post_meta( $post_id, '_contact_home_title_' . $code );
        }

        if ( isset( $_POST['contact_home_description_' . $code] ) ) {
            $desc = wp_kses_post( wp_unslash( $_POST['contact_home_description_' . $code] ) );
            update_post_meta( $post_id, '_contact_home_description_' . $code, $desc );
        } else {
            delete_post_meta( $post_id, '_contact_home_description_' . $code );
        }

        if ( isset( $_POST['contact_button_text_' . $code] ) ) {
            update_post_meta( $post_id, '_contact_button_text_' . $code, sanitize_text_field( wp_unslash( $_POST['contact_button_text_' . $code] ) ) );
        } else {
            delete_post_meta( $post_id, '_contact_button_text_' . $code );
        }

        if ( isset( $_POST['contact_button_link_' . $code] ) ) {
            update_post_meta( $post_id, '_contact_button_link_' . $code, esc_url_raw( wp_unslash( $_POST['contact_button_link_' . $code] ) ) );
        } else {
            delete_post_meta( $post_id, '_contact_button_link_' . $code );
        }
    }
}
